package Repository;

import Models.Ciudad;
import Models.Persona;
import Util.Conexion;
import Util.ConexionBaseDatos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CiudadImpl implements Repository<Ciudad> {

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    
    private Ciudad crearCiudad(ResultSet campo /*Todos los campos lo divido en campo*/ )throws SQLException{/*Distribuimos los campos de la tabla*/
        Ciudad ciudad = new Ciudad();
        ciudad.setId_cuidad(campo.getInt("id_ciudad"));
        ciudad.setNombre_cuidad(campo.getString("nombre_ciudad"));
        return ciudad;
    }
    
    @Override
    public List<Ciudad> listar() {
        List<Ciudad> lista_ciudades = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
                ResultSet fila = stmt.executeQuery("SELECT * FROM Ciudad")) {
            while(fila.next()) {
                lista_ciudades.add(crearCiudad(fila));
                
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las cuidades!");
            System.out.println("Revise el try de la liena 30");
            System.out.println(e);
        }
                
       return lista_ciudades;     
    }

    @Override
    public Ciudad porCodigo(int id_ciudad) {
       Ciudad ciudad = null;
        try (PreparedStatement consulta = getConnection().prepareStatement("SELECT * FROM Ciudad WHERE id_ciudad = ?")) {
            consulta.setInt(1, id_ciudad);//El parametro id cuidad es que mandamos a la consulta stmt 
            /*Pues de que el prepared es para consultar y el Result lo que trae el uno es como el primer dato?por asi decirlo .Next() ahh lo recorre  */
            /**/
            try (ResultSet fila = consulta.executeQuery()) {
                if (fila.next()) {/*Traigo todos los campos de la tabla ciudad*/
                    ciudad = crearCiudad(fila);
                }
            }
        } catch (Exception e) {
            System.out.println("Error no se puedo buscar ciudad Id incorrecto");
            System.out.println("Revisa el try de la linea 48");
            System.out.println(e);
        }finally {
            // Cerrar la conexi�n al finalizar
                try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ciudad;
    }

    @Override
    public void guardar(Ciudad entidad) {
        String sql = """
                     INSERT INTO Ciudad(nombre_ciudad)
                     VALUES(?)""";
        
        try(PreparedStatement stmt = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, entidad.getNombre_cuidad());
            
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar la ciudad, no se modificaron filas.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_cuidad(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Fallo al guardar la persona, no se obtuvo el ID generado.");
                }
            }
        } catch (Exception e) {
            System.out.println("Algo salio salio mal en el envio de los datos ");
            System.out.println("Revise el try de la linea 78.");
            System.out.println(e);
            
        }finally {
             //Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void eliminar(int id) {
    try (PreparedStatement fila = getConnection().prepareStatement("DELETE FROM Ciudad WHERE id_ciudad=?")) {
                fila.setInt(1, id);
                fila.executeUpdate();
            }
    catch (SQLException e) {
                System.out.println("Error eliminando datos.");
                System.out.println("error try linea 115.");
                e.printStackTrace();
            }
    finally {
            // Cerrar la conexi�n al finalizar
            try {
                    Conexion.getInstance().cerrarConexion();
                } catch (SQLException ex) {
                    System.out.println("Error cerrando la conexion de eliminar datos");
                    System.out.println("error try linea 123.");
                    ex.printStackTrace();
                }
            }
    }

    @Override
    public void modificar(Ciudad entidad) {
    
    String sql = """
          UPDATE Ciudad
          SET nombre_ciudad = ?
          WHERE id_ciudad = ?;""" // Agregamos la actualizaci�n del campo direccion_id
        ; 
    try (PreparedStatement fila = getConnection().prepareStatement(sql)) {
        fila.setString(1, entidad.getNombre_cuidad());
        fila.setInt(2, entidad.getId_cuidad());

        int affectedRows = fila.executeUpdate();
    if (affectedRows == 0) {
                    throw new SQLException("Fallo al modificar la persona, no se encontr� el registro.");
                }}
    catch (SQLException e) {
                JOptionPane.showMessageDialog(null, """
                Algo salio mal Modificando la ciudad en CiudadImpl,
                comuniquese con el desarrollador.""");
                System.out.println("Modificando el programa est� el error");
                System.out.println("Verifique el try linea 164.");
                e.printStackTrace();
            }
    finally {
                // Cerrar la conexi�n al finalizar
                try {
                    Conexion.getInstance().cerrarConexion();
                } catch (SQLException ex) {
                    System.out.println("Error cerrando base de datos metodo guardar.");
                    System.out.println("verifique try linea 180.");
                    ex.printStackTrace();
                }
            }
    }
    
    
    
}
