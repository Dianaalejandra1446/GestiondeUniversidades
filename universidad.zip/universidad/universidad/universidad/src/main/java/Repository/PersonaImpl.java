
package Repository;

import Models.Ciudad;
import Models.Persona;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PersonaImpl implements Repository<Persona> {
    private static final Repository ciudadRepository= new CiudadImpl();
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    
    private Persona crearPersona(ResultSet rs )throws SQLException{
        Persona p = new Persona();
        /*Ciudad c = new Ciudad();i*/
        p.setId_persona(rs.getInt("id_persona"));
        p.setTipo_documento_persona(rs.getString("tipo_documento"));
        p.setNumero_documento_persona(rs.getInt("numero"));
        p.setNombre_persona(rs.getString("nombre"));
        p.setApellido_persona(rs.getString("apellido"));
        p.setNumero_telefono_persona(rs.getString("num_telefono"));
        p.setDireccion_persona(rs.getString("direccion"));
        p.setFecha_nacimiento_persona(rs.getDate("fecha_nacimiento").toLocalDate());
        p.setSexo_persona(rs.getString("sexo"));
        
        /*Que se hace aqu
        c.setId_cuidad(rs.getInt("id_ciudad"));i*/
        
        
        //Enviar datos de objetos a un objeto
        int cuidadId = rs.getInt("id_ciudad");
        //Estamos parseando lo que nos dan a un objeto 
        Ciudad ciudad = (Ciudad)ciudadRepository.porCodigo(cuidadId);
        p.setCiudad_persona(ciudad);
        return p;
    }
            
    
    @Override
    public List<Persona> listar() {
        List<Persona> lista_personas = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet fila = stmt.executeQuery("SELECT * FROM Persona")) {
            while(fila.next()) {
                lista_personas.add(crearPersona(fila));   
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las personas!");
            System.out.println("Revise el try de la liena 44");
            System.out.println(e);
        }
        return lista_personas;
    }

    @Override
    public Persona porCodigo(int id) {
        Persona persona = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Persona WHERE id_persona = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    persona = crearPersona(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la persona con c�digo: " + id);
            e.printStackTrace();
        }
        return persona;
    }

    @Override
    public void guardar(Persona entidad) {
        
       String sql = "INSERT INTO Persona(tipo_documento,\n" +
        "numero,\n" +
        "nombre,\n" +
        "apellido,\n" +
        "direccion,\n" +
        "num_telefono,\n" +
        "fecha_nacimiento,\n" +
        "sexo,\n" +
        "id_ciudad ) "+"VALUES(?,?,?,?,?,?,?,?,?)";
       
        try(PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setString(1, entidad.getTipo_documento_persona());
            campo.setInt(2, entidad.getNumero_documento_persona());
            campo.setString(3, entidad.getNombre_persona());
            campo.setString(4, entidad.getApellido_persona());
            campo.setString(5, entidad.getNumero_telefono_persona());
            campo.setString(6, entidad.getDireccion_persona());
            campo.setDate(7, java.sql.Date.valueOf(entidad.getFecha_nacimiento_persona()));
            campo.setString(8, entidad.getSexo_persona());
            campo.setInt(9, entidad.getCiudad_persona().getId_cuidad()); 

            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar la Persona, no se modificaron filas.");
            }
            try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    entidad.setId_persona(1);           
                } else {
                    throw new SQLException("Fallo al guardar la persona, no se obtuvo el ID generado.");
                }
            }
            
        } catch (Exception e) {
            System.out.println("Error al guardar la persona");
            System.out.println("Revise el try en la linea 95");
            System.out.println(e);
        }finally{
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }  
        }
    }
        
    
    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Persona WHERE id_persona = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ninguna persona con el ID especificado: " + id);
            } else {
                System.out.println("Persona eliminada exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar la persona con ID: " + id);
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Persona entidad) {
        String sql = "UPDATE Persona SET tipo_documento = ?, numero = ?, nombre = ?, apellido = ?, direccion = ?, num_telefono = ?, fecha_nacimiento = ?, sexo = ?, id_ciudad = ? WHERE id_persona = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, entidad.getTipo_documento_persona());
            stmt.setInt(2, entidad.getNumero_documento_persona());
            stmt.setString(3, entidad.getNombre_persona());
            stmt.setString(4, entidad.getApellido_persona());
            stmt.setString(5, entidad.getDireccion_persona());
            stmt.setString(6, entidad.getNumero_telefono_persona());
            stmt.setDate(7, java.sql.Date.valueOf(entidad.getFecha_nacimiento_persona()));
            stmt.setString(8, entidad.getSexo_persona());
            stmt.setInt(9, entidad.getCiudad_persona().getId_cuidad());
            stmt.setInt(10, entidad.getId_persona());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ninguna persona con el ID especificado: " + entidad.getId_persona());
            } else {
                System.out.println("Persona modificada exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar la persona con ID: " + entidad.getId_persona());
            e.printStackTrace();
        }
    }

    
}
