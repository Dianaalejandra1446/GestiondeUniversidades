package Repository;

import Models.Piso;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PisoImpl implements Repository<Piso> {

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Piso crearPiso(ResultSet rs) throws SQLException {
        Piso ps = new Piso();
        ps.setId_piso(rs.getInt("id_piso"));
        ps.setNombre_piso(rs.getString("nombre_piso"));
        return ps;
    }

    @Override
    public List<Piso> listar() {
        List<Piso> lista_pisos = new ArrayList<>();
        String sql = "SELECT * FROM Piso";
        try (Connection con = getConnection();
             Statement stmt = con.createStatement();
             ResultSet fila = stmt.executeQuery(sql)) {
            while (fila.next()) {
                lista_pisos.add(crearPiso(fila));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todos los pisos!");
            e.printStackTrace();
        }
        return lista_pisos;
    }

    @Override
    public Piso porCodigo(int id) {
        Piso piso = null;
        String sql = "SELECT * FROM Piso WHERE id_piso = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    piso = crearPiso(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el piso con c�digo: " + id);
            e.printStackTrace();
        }
        return piso;
    }

    @Override
    public void guardar(Piso entidad) {
        String sql = "INSERT INTO Piso(nombre_piso) VALUES (?)";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, entidad.getNombre_piso());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el piso, no se modificaron filas.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_piso(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Fallo al guardar el piso, no se obtuvo el ID generado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar el piso.");
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Piso WHERE id_piso = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n piso con el ID especificado: " + id);
            } else {
                System.out.println("Piso eliminado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el piso con ID: " + id);
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Piso entidad) {
        String sql = "UPDATE Piso SET nombre_piso = ? WHERE id_piso = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, entidad.getNombre_piso());
            stmt.setInt(2, entidad.getId_piso());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n piso con el ID especificado: " + entidad.getId_piso());
            } else {
                System.out.println("Piso modificado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar el piso con ID: " + entidad.getId_piso());
            e.printStackTrace();
        }
    }
}
