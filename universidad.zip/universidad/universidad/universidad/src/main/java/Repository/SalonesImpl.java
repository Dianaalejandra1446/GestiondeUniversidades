
package Repository;

import Models.Edificio;
import Models.Piso;
import Models.Salones;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class SalonesImpl implements Repository<Salones>{
    
    private static final Repository salonesRepository= new SalonesImpl();
    
    private Connection getConnection() throws SQLException {
    return Conexion.getInstance().conectar();
    }
    
    private Salones crearSalones(ResultSet rs)throws SQLException{
        Salones s = new Salones();
        s.setId_salon(rs.getInt("id_salon"));
        s.setCapacidad(rs.getDouble("capacidad"));
        s.setTotal_cupos(rs.getInt("total_cupos"));
        s.setNumero_identificacion(rs.getDouble("num_identificacion"));
        
        int EdificioId = rs.getInt("id_edificio");
        Edificio edificio = (Edificio)salonesRepository.porCodigo(EdificioId);
        s.setEdificio(edificio);
                
        int pisoId = rs.getInt("id_piso");
        Piso piso = (Piso)salonesRepository.porCodigo(pisoId);
        s.setPiso(piso);
        return s;
    }
    
    @Override
    public List<Salones> listar() {
        List<Salones>  lista_salones = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet fila =  stmt.executeQuery("SELECT * FROM Salones")) {
            while(fila.next()) {
                lista_salones.add(crearSalones(fila));
                
            }            
        } catch (Exception e) {
            System.out.println("Algo salio mal al ver todos los salones");
            System.out.println("Revise el try  de la linea 42");
            System.out.println(e);
        }
        return lista_salones;
    }

    @Override
    public Salones porCodigo(int id) {
        Salones salones = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Salones WHERE id_salon = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    salones = crearSalones(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la persona con c�digo: " + id);
            e.printStackTrace();
        }
        return salones;
    }

    @Override
    public void guardar(Salones entidad) {
        String sql = "INSERT INTO Salones (capacidad\n" +
        "total_cupos\n" +
        "num_identificacion\n" +
        "id_edificio\n" +
        "id_piso)"+ "VALUES(?,?,?,?,?)";
        
        try(PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            campo.setDouble(1, entidad.getCapacidad());
            campo.setInt(2, entidad.getTotal_cupos());
            campo.setDouble(3, entidad.getNumero_identificacion());
            campo.setInt(4, entidad.getEdificio().getId_edificio());
            campo.setInt(5, entidad.getPiso().getId_piso());
            
            
            int affectedRows = campo.executeUpdate(); 
            
            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar los salones, no se modificaron filas.");
            }else {
                    throw new SQLException("Fallo al guardar  los salones, no se obtuvo el ID generado.");
            }
            
        }catch (Exception e) {
            System.out.println("Errpr al guardar el salon");
            System.out.println("Revise el try en la linea 72");
            System.out.println(e); 
        }finally{
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
          }
       }

    @Override
    public void eliminar(int id) {
    try (PreparedStatement fila = getConnection().prepareStatement("DELETE FROM Salones WHERE id_salon=?")) {
                fila.setInt(1, id);
                fila.executeUpdate();
            }
    catch (SQLException e) {
                System.out.println("Error eliminando datos.");
                System.out.println("error try linea 117.");
                e.printStackTrace();
            }
    finally {
            // Cerrar la conexi�n al finalizar
            try {
                    Conexion.getInstance().cerrarConexion();
                } catch (SQLException ex) {
                    System.out.println("Error cerrando la conexion de eliminar datos");
                    System.out.println("error try linea 123.");
                    ex.printStackTrace();
                }
            }        
    }

    @Override
    public void modificar(Salones entidad) {
    String sql = """
          UPDATE Salones
          SET capacidad = ?,
          SET total_cupos = ?,
          SET num_identificacion = ?,
          SET id_edificio = ?,
          SET id_piso = ?,
          WHERE id_salon = ?;""" // Agregamos la actualizaci�n del campo direccion_id
        ; 
    try (PreparedStatement fila = getConnection().prepareStatement(sql)) {
        fila.setDouble(1, entidad.getCapacidad());
        fila.setInt(2, entidad.getTotal_cupos());
        fila.setDouble(3, entidad.getNumero_identificacion());
        fila.setInt(4, entidad.getEdificio().getId_edificio());
        fila.setInt(5, entidad.getPiso().getId_piso());
        int affectedRows = fila.executeUpdate();
    if (affectedRows == 0) {
                    throw new SQLException("Fallo al modificar el salon, no se encontr� el registro.");
                }}
    catch (SQLException e) {
                JOptionPane.showMessageDialog(null, """
                Algo salio mal Modificando la ciudad en SalonesImpl,
                comuniquese con el desarrollador.""");
                System.out.println("Modificando el programa est� el error");
                System.out.println("Verifique el try linea 150.");
                e.printStackTrace();
            }
    finally {
                // Cerrar la conexi�n al finalizar
                try {
                    Conexion.getInstance().cerrarConexion();
                } catch (SQLException ex) {
                    System.out.println("Error cerrando base de datos metodo guardar.");
                    System.out.println("verifique try linea 170.");
                    ex.printStackTrace();
                }
            }
    }
                       
}
