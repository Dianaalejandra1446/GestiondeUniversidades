
package Repository;

import Models.Cursos;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CursosImpl implements Repository<Cursos>{
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    
    private Cursos crearCurso(ResultSet rs )throws SQLException{
        Cursos cr = new Cursos();
        cr.setId_curso(rs.getInt("id_curso"));
        cr.setNombre_curso(rs.getString("nombre_curso"));
        cr.setTemas(rs.getString("temas"));
        cr.setCompetencias(rs.getString("competencias"));
        
        return cr;
    }

    @Override
    public List<Cursos> listar() {
       List<Cursos> lista_cursos = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
                ResultSet fila = stmt.executeQuery("SELECT * FROM Cursos")) {
            while(fila.next()) {
                lista_cursos.add(crearCurso(fila));
                
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las cursos!");
            System.out.println("Revise el try de la liena 33");
            System.out.println(e);
        }
        return lista_cursos;
    }

    @Override
    public Cursos porCodigo(int id) {
        Cursos cursos = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Cursos WHERE id_curso = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cursos = crearCurso(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el curso con c�digo: " + id);
            e.printStackTrace();
        }
        return cursos;        
    }

    @Override
    public void guardar(Cursos entidad) {
        String sql = "INSERT INTO Cursos(id_curso\n" +
            "nombre_curso\n" +
            "temas\n" +
            "competencias)"+"VALUES(?,?,?,?)";
        
        try (PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
           campo.setInt(1, entidad.getId_curso());
           campo.setString(2, entidad.getNombre_curso());
           campo.setString(2, entidad.getTemas());
           campo.setString(3, entidad.getCompetencias());
           
            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el curso, no se modificaron filas.");
            }
            try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    entidad.setId_curso(1);           
                } else {
                    throw new SQLException("Fallo al guardar el curso, no se obtuvo el ID generado.");
                }
                 
            }
        } catch (Exception e) {
            System.out.println("Error al guardar el curso");
            System.out.println("Revse el try en la linea 74");
            System.out.println(e);
        }finally{
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }  
        
    }


  }

    @Override
    public void eliminar(int id) {
        try (PreparedStatement stmt = getConnection().prepareStatement("DELETE FROM Cursos WHERE id_curso=?")) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error eliminando curso.");
            e.printStackTrace();
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                System.out.println("Error cerrando la conexi�n de eliminaci�n de curso.");
                ex.printStackTrace();
            }
        }        
    }

    @Override
    public void modificar(Cursos entidad) {
        String sql = "UPDATE Cursos SET nombre_curso=?, temas=?, competencias=? WHERE id_curso=?";

        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setString(1, entidad.getNombre_curso());
            stmt.setString(2, entidad.getTemas());
            stmt.setString(3, entidad.getCompetencias());
            stmt.setInt(4, entidad.getId_curso());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Fallo al modificar el curso, no se encontr� el registro.");
            }
        } catch (SQLException e) {
            System.out.println("Error modificando el curso.");
            e.printStackTrace();
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                System.out.println("Error cerrando la conexi�n de modificaci�n de curso.");
                ex.printStackTrace();
            }
        }
    }        
}

    

