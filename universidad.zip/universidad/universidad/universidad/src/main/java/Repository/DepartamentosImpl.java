
package Repository;

import Models.Departamento;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DepartamentosImpl implements Repository<Departamento>{
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    private Departamento crearDepartamento(ResultSet rs) throws SQLException {
        Departamento dp = new Departamento();

        dp.setId_departamento(rs.getInt("id_departamento"));
        dp.setNombre_departamento(rs.getString("nombre"));

        return dp;
    }


    @Override
    public List<Departamento> listar() {
        List<Departamento> listar_departamentos = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
                ResultSet fila = stmt.executeQuery("SELECT * FROM Departamento;")) {
            while(fila.next()) {
                listar_departamentos.add(crearDepartamento(fila));
                
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las personas!");
            System.out.println("Revise el try de la liena 33");
            System.out.println(e);
        }
        return listar_departamentos;
    }

    @Override
    public Departamento porCodigo(int id) {
        Departamento departamento = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Departamento WHERE id_departamento = ?;")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    departamento = crearDepartamento(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el departamento con c�digo: " + id);
            e.printStackTrace();
        }
        return departamento;
    }

    @Override
    public void guardar(Departamento entidad) {
        String sql = "INSERT INTO Departamento(id_departamento\n" +
        "nombre)"+"VALUES (?,?);";
        
        try(PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setString(1, entidad.getNombre_departamento());
            
            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el departamento, no se modificaron filas.");
            }
            try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    entidad.setId_departamento(1);           
                } else {
                    throw new SQLException("Fallo al guardar la departamento, no se obtuvo el ID generado.");
                }
            }            

        } catch (Exception e) {
            System.out.println("Error al guardar la persona");
            System.out.println("Revse el try en la linea 95");
            System.out.println(e);
        }finally{
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
        }
    }
   }     
@Override
    public void eliminar(int id) {
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("DELETE FROM Departamento WHERE id_departamento = ?;")) {

            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n departamento con el ID especificado: " + id);
            } else {
                System.out.println("Departamento eliminado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el departamento con ID: " + id);
            e.printStackTrace();
        }
    }

@Override
    public void modificar(Departamento entidad) {
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("UPDATE Departamento SET nombre = ? WHERE id_departamento = ?;")) {

            stmt.setString(1, entidad.getNombre_departamento());
            stmt.setInt(2, entidad.getId_departamento());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n departamento con el ID especificado: " + entidad.getId_departamento());
            } else {
                System.out.println("Departamento modificado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar el departamento con ID: " + entidad.getId_departamento());
            e.printStackTrace();
        }
    }

}
