
package Repository;

import java.util.List;

public interface Repository<T> {
    List<T> listar();

    T porCodigo(int id);

    void guardar(T entidad);

    void eliminar(int id);

    void modificar(T entidad);
}
