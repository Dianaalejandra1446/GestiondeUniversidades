package Repository;

import Models.Programa;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProgramaImpl implements Repository<Programa>{
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Programa crearProgarma(ResultSet rs )throws SQLException{
        Programa p = new Programa();
        p.setId_programa(rs.getInt("id_programa"));
        p.setNombre_programa(rs.getString("nombre_programa"));
        p.setNivel_programa(rs.getString("nivel_programa"));
        p.setCreditos_programa(rs.getInt("creditos_programa"));
        return p;
    }
    
    @Override
    public List<Programa> listar() {
        List<Programa> lista_programas = new ArrayList<>();
        try (Statement stmt = getConnection().createStatement();
            ResultSet fila = stmt.executeQuery("SELECT * FROM Programas")) {
            
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas los programas!");
            System.out.println("Revise el try de la liena 31");
            System.out.println(e);
        }
        return lista_programas;
    }

    @Override
    public Programa porCodigo(int id) {
        Programa programa = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Programas WHERE id_programa = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    programa = crearProgarma(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el progarama con c�digo: " + id);
            e.printStackTrace();
        }
        return programa;
        
    }

    @Override
    public void guardar(Programa entidad) {
        String sql = "INSERT INTO Programas (nombre_programa\n" +
        "nivel_programa\n" +
        "creditos_programa)"+ "VALUES(?,?,?)";
        
        try (PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setString(1, entidad.getNombre_programa());
            campo.setString(2, entidad.getNivel_programa());
            campo.setInt(3, entidad.getCreditos_programa());
            
            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el programa, no se modificaron filas.");
            }
            try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    entidad.setId_programa(1);           
                } else {
                    throw new SQLException("Fallo al guardar el programa, no se obtuvo el ID generado.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error al guardar el programa");
            System.out.println("Revise el try del 69.");
            System.out.println(e);
        }
    }

    @Override
    public void eliminar(int id) {
    String sql = "DELETE FROM Programas WHERE id_programa = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al eliminar el programa con ID: " + id);
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }

    @Override
    public void modificar(Programa entidad) {
    String sql = "UPDATE Programas SET nombre_programa = ?, nivel_programa = ?, creditos_programa = ? WHERE id_programa = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setString(1, entidad.getNombre_programa());
        stmt.setString(2, entidad.getNivel_programa());
        stmt.setInt(3, entidad.getCreditos_programa());
        stmt.setInt(4, entidad.getId_programa());

        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al modificar el programa con ID: " + entidad.getId_programa());
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }        
    }
    
}
