package Repository;

import Models.Alumnos;
import Models.Persona;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AlumnosImpl implements Repository<Alumnos> {
    private static final Repository personaRepository = new PersonaImpl();

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Alumnos crearAlumno(ResultSet rs) throws SQLException {
        Alumnos a = new Alumnos();
        a.setId_alumno(rs.getInt("id_alumno"));
        a.setNum_carnet((int) rs.getDouble("num_carnet"));
        
        int personaId = rs.getInt("id_persona");
        Persona persona = (Persona)personaRepository.porCodigo(personaId);
        a.setPersona(persona);
        return a;
    }

    @Override
    public List<Alumnos> listar() {
        List<Alumnos> lista_alumnos = new ArrayList<>();
        try (Connection con = getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Alumnos")) {

            while (rs.next()) {
                lista_alumnos.add(crearAlumno(rs));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todas los Alumnos!");
            e.printStackTrace();
        }
        return lista_alumnos;
    }

    @Override
    public Alumnos porCodigo(int id) {
        Alumnos alumno = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Alumnos WHERE id_alumno = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    alumno = crearAlumno(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el alumno con c�digo: " + id);
            e.printStackTrace();
        }
        return alumno;
    }

    @Override
    public void guardar(Alumnos entidad) {
        String sql = "INSERT INTO Alumnos (id_persona, num_carnet) VALUES (?, ?)";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, entidad.getPersona().getId_persona());
            stmt.setDouble(2, entidad.getNum_carnet());
            
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el alumno, no se modificaron filas.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_alumno(generatedKeys.getInt(1));           
                } else {
                    throw new SQLException("Fallo al guardar el alumno, no se obtuvo el ID generado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar el alumno");
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Alumnos WHERE id_alumno = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n alumno con el ID especificado: " + id);
            } else {
                System.out.println("Alumno eliminado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el alumno con ID: " + id);
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Alumnos entidad) {
        String sql = "UPDATE Alumnos SET id_persona = ?, num_carnet = ? WHERE id_alumno = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, entidad.getPersona().getId_persona());
            stmt.setDouble(2, entidad.getNum_carnet());
            stmt.setInt(3, entidad.getId_alumno());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n alumno con el ID especificado: " + entidad.getId_alumno());
            } else {
                System.out.println("Alumno modificado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar el alumno con ID: " + entidad.getId_alumno());
            e.printStackTrace();
        }
    }

}
