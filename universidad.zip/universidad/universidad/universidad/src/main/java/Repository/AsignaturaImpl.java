package Repository;

import Models.Asignatura;
import Models.Cursos;
import Models.Periodo;
import Models.Profesor;
import Models.Programa;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AsignaturaImpl implements Repository<Asignatura>{
    private static final Repository periodoRepository= new PeriodoImpl();
    private static final Repository programaRepository = new ProgramaImpl();
    private static final Repository cursoRepository =  new CursosImpl();
    private static final Repository  profesorRepository = new ProfesorImpl();
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    
    private Asignatura crearAsignatura(ResultSet rs )throws SQLException{
        Asignatura a = new Asignatura();
        a.setId_asignatura(rs.getInt("id_asignatura"));
        a.setNombre_combinado(rs.getString("nombre_combinado"));
        a.setCantidad_creditos(rs.getInt("cantidad_creditos"));
        a.setCupos(rs.getInt("cupos"));
        
        int periodoId = rs.getInt("id_periodo");
        Periodo periodo = (Periodo)periodoRepository.porCodigo(periodoId);
        a.setPeriodo(periodo);
        
        int profesorId = rs.getInt("id_profesor");
        Profesor profesor = (Profesor)profesorRepository.porCodigo(profesorId);
        a.setProfesor(profesor);
        
        int programaId = rs.getInt("id_programa");
        Programa programa = (Programa)programaRepository.porCodigo(programaId);
        a.setPrograma(programa);
        
        int cursoId = rs.getInt("id_curso");
        Cursos curso = (Cursos)cursoRepository.porCodigo(cursoId);
        a.setCursos(curso);
        return a;
    }

    @Override
    public List<Asignatura> listar() {
        List<Asignatura> lista_asignaturas  = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
                ResultSet fila = stmt.executeQuery("SELECT * FROM Asignatura;")) {
            while(fila.next()) {
                lista_asignaturas.add(crearAsignatura(fila));
                
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las asignaturas!");
            System.out.println("Revise el try de la liena 54");
            System.out.println(e);
        }
        return lista_asignaturas;
    }

    @Override
    public Asignatura porCodigo(int id) {
        Asignatura asignatura = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Asignatura WHERE id_asignatura = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    asignatura = crearAsignatura(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la asignatura con c�digo: " + id);
            e.printStackTrace();
        }
        return asignatura;
    }

    @Override
    public void guardar(Asignatura entidad) {
        String sql = "INSERT INTO Asignatura(nombre_combinado\n" +
        "cantidad_creditos\n" +
        "cupos\n" +
        "id_profesor\n" +
        "id_periodo\n" +
        "id_programa\n" +
        "id_curso)"+"VALUES(?,?,?,?,?,?,?)";
        
        try (PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setString(1,entidad.getNombre_combinado());
            campo.setInt(2, entidad.getCantidad_creditos());
            campo.setInt(3, entidad.getCupos());
            campo.setInt(4, entidad.getProfesor().getId_profesor());
            campo.setInt(5, entidad.getPrograma().getId_programa());
            campo.setInt(6, entidad.getCursos().getId_curso());

        
        int affectedRows = campo.executeUpdate();

        if (affectedRows == 0) {
            throw new SQLException("Fallo al guardar la asignatura, no se modificaron filas.");
        }
        try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
            if (generatedKeys.next()){
                entidad.setId_asignatura(1);           
            } else {
                throw new SQLException("Fallo al guardar la asignatura, no se obtuvo el ID generado.");
            }
        }
        } catch (Exception e) {
            System.err.println("Error al guardar la asignatura");
            System.err.println("Revise el try de la linea 95 ");
            System.err.println(e);
        }    

    }
    
    @Override
    public void eliminar(int id) {
    try (PreparedStatement fila = getConnection().prepareStatement("DELETE FROM Asignatura WHERE id_asignatura=?")) {
                fila.setInt(1, id);
                fila.executeUpdate();
            }
    catch (SQLException e) {
                System.out.println("Error eliminando datos.");
                System.out.println("error try linea 129.");
                e.printStackTrace();
            }
    finally {
            // Cerrar la conexi�n al finalizar
            try {
                    Conexion.getInstance().cerrarConexion();
                } catch (SQLException ex) {
                    System.out.println("Error cerrando la conexion de eliminar datos");
                    System.out.println("error try linea 140.");
                    ex.printStackTrace();
                }
            }        
    }

    @Override
    public void modificar(Asignatura entidad) {
    String sql = """
          UPDATE Asignatura
          SET nombre_combinado = ?,
              cantidad_creditos = ?,
              cupos = ?,
              id_programa = ?,
              id_curso = ?,
              id_profesor = ?  
              WHERE id_ciudad = ?;""" // Agregamos la actualizaci�n del campo direccion_id
        ; 
        try  (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1,entidad.getNombre_combinado());
            stmt.setInt(2, entidad.getCantidad_creditos());
            stmt.setInt(3, entidad.getCupos());
            stmt.setInt(4,entidad.getPrograma().getId_programa());
            stmt.setInt(5, entidad.getCursos().getId_curso());
            stmt.setInt(6, entidad.getProfesor().getId_profesor());
        } catch (SQLException e) {
            System.out.println("Error al modificar el horario con ID: " + entidad.getId_asignatura());
            e.printStackTrace();
        }finally{
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
