package Repository;

import Models.Departamento;
import Models.Persona;
import Models.Profesor;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProfesorImpl implements Repository<Profesor> {
    private static final Repository<Persona> personaRepository = new PersonaImpl();
    private static final Repository<Departamento> departamentoRepository = new DepartamentosImpl();

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Profesor crearProfesor(ResultSet rs) throws SQLException {
        Profesor pf = new Profesor();
        pf.setId_profesor(rs.getInt("id_profesor"));

        int id_persona = rs.getInt("id_persona");
        Persona persona = personaRepository.porCodigo(id_persona);
        pf.setPersona(persona);

        int id_departamento = rs.getInt("id_departamento");
        Departamento departamento = departamentoRepository.porCodigo(id_departamento);
        pf.setDepartamentos(departamento);
        
        return pf;
    }

    @Override
    public List<Profesor> listar() {
        List<Profesor> lista_profesores = new ArrayList<>();
        String sql = "SELECT * FROM Profesor";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet fila = stmt.executeQuery()) {
            while (fila.next()) {
                lista_profesores.add(crearProfesor(fila));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todos los profesores!");
            e.printStackTrace();
        }
        return lista_profesores;
    }

    @Override
    public Profesor porCodigo(int id) {
        Profesor pf = null;
        String sql = "SELECT * FROM Profesor WHERE id_profesor = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pf = crearProfesor(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el profesor con c�digo: " + id);
            e.printStackTrace();
        }
        return pf;
    }

    @Override
    public void guardar(Profesor entidad) {
        String sql = "INSERT INTO Profesor(id_persona, id_departamento) VALUES (?, ?)";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, entidad.getPersona().getId_persona());
            stmt.setInt(2, entidad.getDepartamentos().getId_departamento());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Fallo en guardar el profesor, no se modificaron filas.");
            }
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_profesor(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Fallo al guardar el profesor, no se obtuvo el ID generado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar el profesor.");
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Profesor WHERE id_profesor = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n profesor con el ID especificado: " + id);
            } else {
                System.out.println("Profesor eliminado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el profesor con ID: " + id);
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Profesor entidad) {
        String sql = "UPDATE Profesor SET id_persona = ?, id_departamento = ? WHERE id_profesor = ?";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, entidad.getPersona().getId_persona());
            stmt.setInt(2, entidad.getDepartamentos().getId_departamento());
            stmt.setInt(3, entidad.getId_profesor());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n profesor con el ID especificado: " + entidad.getId_profesor());
            } else {
                System.out.println("Profesor modificado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar el profesor con ID: " + entidad.getId_profesor());
            e.printStackTrace();
        }
    }
}
