package Repository;

import Models.Alumnos;
import Models.Asignatura;
import Models.Matricula;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MatriculaImpl implements Repository<Matricula>{
    private static final Repository alumnoRepository = new AlumnosImpl();
    private static final Repository asignaturaRepository = new AsignaturaImpl();

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Matricula crearMatricula(ResultSet rs) throws SQLException {
        Matricula m = new Matricula();
        m.setId_matricula(rs.getInt("id_matricula"));
        
        int alumnoId = rs.getInt("id_alumno");
        Alumnos alumno = (Alumnos) alumnoRepository.porCodigo(alumnoId); // Suponiendo que tienes un repositorio para Alumnos
        m.setAlumno(alumno);

        int asignaturaId = rs.getInt("id_asignatura");
        Asignatura asignatura = (Asignatura) asignaturaRepository.porCodigo(asignaturaId); // Suponiendo que tienes un repositorio para Asignatura
        m.setAsignatura(asignatura);

        return m;
    }

    @Override
    public List<Matricula> listar() {
        List<Matricula> lista_matriculas = new ArrayList<>();
        try (Connection con = getConnection();
             Statement stmt = con.createStatement();
             ResultSet fila = stmt.executeQuery("SELECT * FROM matriculas;")) {
            while (fila.next()) {
                lista_matriculas.add(crearMatricula(fila));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todas las matr�culas!");
            System.out.println("Revise el try de la l�nea 39");
            System.out.println(e);
        }
        return lista_matriculas;
    }

    @Override
    public Matricula porCodigo(int id) {
        Matricula matricula = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM matriculas WHERE id_matricula = ?;")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    matricula = crearMatricula(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la matr�cula con c�digo: " + id);
            e.printStackTrace();
        }
        return matricula;
    }

    @Override
    public void guardar(Matricula entidad) {
        String sql = "INSERT INTO matrivulas(id_alumno, id_asignatura) VALUES (?, ?);";

        try (Connection con = getConnection();
             PreparedStatement campo = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setInt(1, entidad.getAlumno().getId_alumno());
            campo.setInt(2, entidad.getAsignatura().getId_asignatura());

            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar la matr�cula, no se modificaron filas.");
            }
            try (ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_matricula(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Fallo al guardar la matr�cula, no se obtuvo el ID generado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar la matr�cula");
            System.out.println("Revise el try en la l�nea 67");
            System.out.println(e);
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM matriculas WHERE id_matricula = ?:";

        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al eliminar la matr�cula con ID: " + id);
            e.printStackTrace();
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }        
    }

    @Override
    public void modificar(Matricula entidad) {
        String sql = "UPDATE matriculas SET id_alumno = ?, id_asignatura = ? WHERE id_matricula = ?;";

        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, entidad.getAlumno().getId_alumno());
            stmt.setInt(2, entidad.getAsignatura().getId_asignatura());
            stmt.setInt(3, entidad.getId_matricula());

            stmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al modificar la matr�cula con ID: " + entidad.getId_matricula());
            e.printStackTrace();
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }        
}

