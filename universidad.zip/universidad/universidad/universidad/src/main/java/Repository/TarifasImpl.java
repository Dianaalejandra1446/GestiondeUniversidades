
package Repository;

import Models.Periodo;
import Models.Programa;
import Models.Tarifas;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TarifasImpl implements Repository<Tarifas>{
    private static final Repository periodoRepository= new PeriodoImpl();
    private static final Repository programaRepository= new PeriodoImpl();
    
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    
    private Tarifas crearTarifa(ResultSet rs )throws SQLException{
        Tarifas t = new Tarifas();
       
        t.setId_tarifa(rs.getInt("id_tarifa"));
        t.setValor_credito(rs.getDouble("valor_credito"));
        
        int programaId = rs.getInt("id_programa");
        Programa programa = (Programa)programaRepository.porCodigo(programaId);
        t.setPrograma(programa);
        
        int periodoId = rs.getInt("id_periodo");
        Periodo periodo = (Periodo)periodoRepository.porCodigo(periodoId);
        t.setPeriodo(periodo);
        return t;
        
    }
    
    
    @Override
    public List<Tarifas> listar() {
        List<Tarifas> lista_tarifas = new ArrayList<>();
        try (Statement stmt = getConnection().createStatement();
            ResultSet fila = stmt.executeQuery("SELECT * FROM Tarifas")){
            while(fila.next()) {
                lista_tarifas.add(crearTarifa(fila));   
            }     
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas las tarfias!");
            System.out.println("Revise el try de la liena 43");
            System.out.println(e);
        }
        return lista_tarifas;
    }

    @Override
    public Tarifas porCodigo(int id) {
        Tarifas tarifas = null;
        try (Connection con = getConnection();
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM Tarifas WHERE id_tarifa = ?")) {

        stmt.setInt(1, id);
        try (ResultSet rs = stmt.executeQuery()) {
           if (rs.next()) {
               tarifas = crearTarifa(rs);
           }
        }
        } catch (SQLException e) {
            System.out.println("Error al obtener la tarifa con c�digo: " + id);
            e.printStackTrace();
        }
        return tarifas;
    }

    @Override
    public void guardar(Tarifas entidad) {
        
        String sql = "INSERT INTO Tarifas(valor_credito\n" +
        "id_programa\n" +
        "id_periodo)"+ "VALUES (?,?,?)";
        
        try (PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setDouble(1, entidad.getValor_credito());
            campo.setInt(2, entidad.getPrograma().getId_programa());
            campo.setInt(3, entidad.getPeriodo().getId_periodo());

            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar la tarifa, no se modificaron filas.");
            }
            try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    entidad.setId_tarifa(1);           
                } else {
                    throw new SQLException("Fallo al guardar la tarifa, no se obtuvo el ID generado.");
                }
            }            
            
        } catch (Exception e) {
            System.out.println("Error al guardar las tarifas");
            System.out.println("Revise el try en la linea 70");
            System.out.println(e);            
        }finally{
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void eliminar(int id) {
    String sql = "DELETE FROM Tarifas WHERE id_tarifa = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al eliminar la tarifa con ID: " + id);
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }

    @Override
    public void modificar(Tarifas entidad) {
            String sql = "UPDATE Tarifas SET valor_credito = ?, id_programa = ?, id_periodo = ? WHERE id_tarifa = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setDouble(1, entidad.getValor_credito());
        stmt.setInt(2, entidad.getPrograma().getId_programa());
        stmt.setInt(3, entidad.getPeriodo().getId_periodo());
        stmt.setInt(4, entidad.getId_tarifa());

        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al modificar la tarifa con ID: " + entidad.getId_tarifa());
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }
    
}
