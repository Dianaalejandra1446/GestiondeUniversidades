
package Repository;

import Models.Asignatura;
import Models.Horario;
import Models.Salones;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class HorarioImpl implements Repository<Horario>{

    private static final Repository salonesRepository= new SalonesImpl();
    private static final Repository asignaturaRepository= new AsignaturaImpl();
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }
    private Horario crearHorario(ResultSet rs )throws SQLException{
        Horario h = new Horario();
        
        h.setId_horario(rs.getInt("id_horario"));
        h.setDia(rs.getString("dia"));
        h.setHora_inicio(rs.getString("hora_inicio"));
        h.setHora_fin(rs.getString("hora_fin"));
        
        //Datos del objeto
        int asignaturaId = rs.getInt("id_asignatura");
        Asignatura asignatura = (Asignatura)asignaturaRepository.porCodigo(asignaturaId);
        h.setAsignatura(asignatura);
        
        int salonesId = rs.getInt("id_salon");
        Salones salones = (Salones)salonesRepository.porCodigo(salonesId);
        h.setSalon(salones);
        
        return h;
    }
    @Override
    public List<Horario> listar() {
        List<Horario> lista_horarios = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet fila = stmt.executeQuery("SELECT * FROM Horario")) {
            while(fila.next()) {
                lista_horarios.add(crearHorario(fila));
                
            }
        } catch (Exception e) {
            System.out.println("Algo salio mal en la consulta de ver todas los horarios!");
            System.out.println("Revise el try de la liena 46");
            System.out.println(e);
        }        
        return null;
    }

    @Override
    public Horario porCodigo(int id) {
        Horario horario = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Horario WHERE id_horario = ?")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    horario = crearHorario(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el horario con c�digo: " + id);
            e.printStackTrace();
        }        
        return horario;
    }

    @Override
    public void guardar(Horario entidad) {
        String sql = "INSERT INTO Horario(dia\n" +
        "hora_inicio\n" +
        "hora_fin\n" +
        "id_asignatura\n" +
        "id_salon)"+ "VALUES(?,?,?,?,?)";
        try(PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
        campo.setString(1, entidad.getHora_inicio());
        campo.setString(1, entidad.getHora_fin());
        campo.setInt(3, entidad.getAsignatura().getId_asignatura());
        campo.setInt(4, entidad.getSalon().getId_salon());

        int affectedRows = campo.executeUpdate();

        if (affectedRows == 0) {
            throw new SQLException("Fallo al guardar el horario, no se modificaron filas.");
        }
        try(ResultSet generatedKeys = campo.getGeneratedKeys()) {
            if (generatedKeys.next()){
                entidad.setId_horario(1);           
            } else {
                throw new SQLException("Fallo al guardar la persona, no se obtuvo el ID generado.");
            }
        }
            
        } catch (Exception e) {
            System.out.println("Error al guardar la persona");
            System.out.println("Revse el try en la linea 95");
            System.out.println(e);
        }finally{
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }  
        }        
    }

    @Override
    public void eliminar(int id) {
    String sql = "DELETE FROM Horario WHERE id_horario = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al eliminar el horario con ID: " + id);
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }        
    }

    @Override
    public void modificar(Horario entidad) {
    String sql = "UPDATE Horario SET dia = ?, hora_inicio = ?, hora_fin = ?, id_asignatura = ?, id_salon = ? WHERE id_horario = ?";

    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setString(1, entidad.getDia());
        stmt.setString(2, entidad.getHora_inicio());
        stmt.setString(3, entidad.getHora_fin());
        stmt.setInt(4, entidad.getAsignatura().getId_asignatura());
        stmt.setInt(5, entidad.getSalon().getId_salon());

        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al modificar el horario con ID: " + entidad.getId_horario());
        e.printStackTrace();
    } finally {
        // Cerrar la conexi�n al finalizar
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }        
    }
    
}
