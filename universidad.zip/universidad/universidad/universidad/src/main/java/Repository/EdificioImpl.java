package Repository;

import Models.Edificio;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EdificioImpl implements Repository<Edificio> {

    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }

    private Edificio crearEdificio(ResultSet rs) throws SQLException {
        Edificio e = new Edificio();
        e.setId_edificio(rs.getInt("id_edificio"));
        e.setNombre_edificio(rs.getString("nombre_edificio"));
        return e;
    }

    @Override
    public List<Edificio> listar() {
        List<Edificio> lista_edificios = new ArrayList<>();
        try (Statement stmt = getConnection().createStatement()) {
            ResultSet fila = stmt.executeQuery("SELECT * FROM Edificio;");
            while (fila.next()) {
                lista_edificios.add(crearEdificio(fila));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todos los edificios!");
            e.printStackTrace();
        }
        return lista_edificios;
    }

    @Override
    public Edificio porCodigo(int id) {
        Edificio edificio = null;
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Edificio WHERE id_edificio = ?;")) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    edificio = crearEdificio(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el edificio con c�digo: " + id);
            e.printStackTrace();
        }
        return edificio;
    }

    @Override
    public void guardar(Edificio entidad) {
        String sql = "INSERT INTO Edificio (nombre_edificio) VALUES (?);";
 
        try (PreparedStatement campo = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            campo.setString(1, entidad.getNombre_edificio());
            
            int affectedRows = campo.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el edificio, no se modificaron filas.");
            }
            try (ResultSet generatedKeys = campo.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_edificio(generatedKeys.getInt(1));
                } else {
                    throw new SQLException("Fallo al guardar el edificio, no se obtuvo el ID generado.");
                }
            }        
        } catch (SQLException e) {
            System.out.println("Error al guardar el edificio");
            e.printStackTrace();
        } finally {
            // Cerrar la conexi�n al finalizar
            try {
                Conexion.getInstance().cerrarConexion();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }  
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Edificio WHERE id_edificio = ?;";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n edificio con el ID especificado: " + id);
            } else {
                System.out.println("Edificio eliminado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar eliminar el edificio con ID: " + id);
            e.printStackTrace();
        }
    }

    @Override
    public void modificar(Edificio entidad) {
        String sql = "UPDATE Edificio SET nombre_edificio = ? WHERE id_edificio = ?;";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, entidad.getNombre_edificio());
            stmt.setInt(2, entidad.getId_edificio());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("No se encontr� ning�n edificio con el ID especificado: " + entidad.getId_edificio());
            } else {
                System.out.println("Edificio modificado exitosamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al intentar modificar el edificio con ID: " + entidad.getId_edificio());
            e.printStackTrace();
        }
    }

}
