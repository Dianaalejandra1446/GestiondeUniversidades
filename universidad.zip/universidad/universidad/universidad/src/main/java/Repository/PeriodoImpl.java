package Repository;

import Models.Periodo;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class PeriodoImpl implements Repository<Periodo>{
    
    private Connection getConnection() throws SQLException {
        return Conexion.getInstance().conectar();
    }    

    private Periodo crearPeriodo(ResultSet rs )throws SQLException{
        Periodo p = new Periodo();
        
        p.setId_periodo(rs.getInt("id_periodo"));
        p.setNombre_periodo(rs.getString("nombre"));
        p.setCodigo(rs.getInt("codigo"));
        p.setAnio(rs.getInt("anio"));
        p.setSemestre_correspondiente(rs.getString("semestre_correspondiente"));
        p.setCredito_periodo(rs.getInt("creditos_periodo"));
        return p;
    }
    
    @Override
    public List<Periodo> listar() {
        List<Periodo> lista_periodos = new ArrayList<>();
         try (Connection con = getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Periodo;")) {

            while (rs.next()) {
                lista_periodos.add(crearPeriodo(rs));
            }
        } catch (SQLException e) {
            System.out.println("Algo sali� mal en la consulta de ver todos los periodos!");
            e.printStackTrace();
        }
         return  lista_periodos;
    }

    @Override
    public Periodo porCodigo(int id) {
        Periodo periodo = null;
        try(Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM Periodo WHERE id_periodo = ?;")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    periodo = crearPeriodo(rs);
                }
            }            
        } catch (SQLException e) {
            System.out.println("Error al obtener el periodo con c�digo: " + id);
            e.printStackTrace();
        }
        return periodo;
    }

    @Override
    public void guardar(Periodo entidad) {
        String sql = "INSERT INTO Periodo(nombre\n" +
        "codigo\n" +
        "a�o\n" +
        "semestre_correspondiente\n" +
        "creditos_periodo)"+ "VALUES (?,?,?,?,?);";
        try (Connection con = getConnection();
             PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, entidad.getNombre_periodo());
            stmt.setInt(2, entidad.getCodigo());
            stmt.setInt(3, entidad.getAnio());
            stmt.setString(4, entidad.getSemestre_correspondiente());
            stmt.setInt(5, entidad.getCredito_periodo());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Fallo al guardar el alumno, no se modificaron filas.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    entidad.setId_periodo(generatedKeys.getInt(1));           
                } else {
                    throw new SQLException("Fallo al guardar el periodo, no se obtuvo el ID generado.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error al guardar el periodo");
            e.printStackTrace();            
        }
    }

@Override
public void eliminar(int id) {
    String sql = "DELETE FROM Periodo WHERE id_periodo = ?";
    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al eliminar el periodo con ID: " + id);
        e.printStackTrace();
    } finally {
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            System.out.println("Error cerrando la conexi�n al eliminar el periodo");
            ex.printStackTrace();
        }
    }
}

@Override
public void modificar(Periodo entidad) {
    String sql = "UPDATE Periodo SET nombre = ?, codigo = ?, a�o = ?, semestre_correspondiente = ?, creditos_periodo = ? WHERE id_periodo = ?;";
    try (Connection con = getConnection();
         PreparedStatement stmt = con.prepareStatement(sql)) {
        stmt.setString(1, entidad.getNombre_periodo());
        stmt.setInt(2, entidad.getCodigo());
        stmt.setInt(3, entidad.getAnio());
        stmt.setString(4, entidad.getSemestre_correspondiente());
        stmt.setInt(5, entidad.getCredito_periodo());
        stmt.setInt(6, entidad.getId_periodo());
        stmt.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error al modificar el periodo con ID: " + entidad.getId_periodo());
        e.printStackTrace();
    } finally {
        try {
            Conexion.getInstance().cerrarConexion();
        } catch (SQLException ex) {
            System.out.println("Error cerrando la conexi�n al modificar el periodo");
            ex.printStackTrace();
        }
    }
}   
}
