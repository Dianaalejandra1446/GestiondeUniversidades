package Principal;

import Services.Services;
import Views.ConexionFabrica;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class Main {
    public static void main(String[] args) {
    ConexionFabrica fabrica = new ConexionFabrica();

        String[][] data = {
                {"1. Persona", "6. Matricula"},
                {"2. Profesor", "7. Asignatura"},
                {"3. Alumno", "8. Cursos"},
                {"4. Ciudad", "9. Periodo"},
                {"5. Departamento", "10. Programa"},
                {"11. Tarifas", "12. Salones"},
                {"13. Horarios", "14. Piso"},
                {"", "15. Edificio"}
        };

        // Encabezados de la tabla
        String[] columnNames = {"Opci�n 1", "Opci�n 2"};

        // Crear una tabla
        JTable table = new JTable(data, columnNames);
        table.setRowHeight(30); // Ajustar la altura de las filas para una mejor legibilidad
        table.setPreferredScrollableViewportSize(table.getPreferredSize());

        // Mostrar la tabla en un cuadro de di�logo de JOptionPane
        Object selectedOption = JOptionPane.showInputDialog(
                null,
                new JScrollPane(table),
                "Seleccione una opci�n",
                JOptionPane.PLAIN_MESSAGE,
                null,
                null,
                null
        );

        byte op = -1; // Valor por defecto si no se proporciona un n�mero v�lido

        if (selectedOption instanceof String) {
            try {
                op = Byte.parseByte((String) selectedOption);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese una opci�n num�rica v�lida.");
            }
        }

        while (op < 1 || op > 15) {
            String userInput = JOptionPane.showInputDialog("Ingrese la opci�n que desea:");

            try {
                op = Byte.parseByte(userInput);
                if (op < 1 || op > 15) {
                    JOptionPane.showMessageDialog(null, "Seleccione una opci�n v�lida, vuelva a intentarlo");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese una opci�n num�rica v�lida.");
            }
        }

        // Ejecutar la opci�n seleccionada
        String servicio = switch (op) {
            case 1 -> "persona";
            case 2 -> "profesor";
            case 3 -> "alumno";
            case 4 -> "ciudad";
            case 5 -> "departamento";
            case 6 -> "matricula";
            case 7 -> "asignatura";
            case 8 -> "cursos";
            case 9 -> "periodo";
            case 10 -> "programa";
            case 11 -> "tarifa";
            case 12 -> "salones";
            case 13 -> "horario";
            case 14 -> "piso";
            case 15 -> "edificio";
            default -> throw new IllegalStateException("Opci�n inv�lida: " + op);
        };

        Services servicioSeleccionado = fabrica.getConexion(servicio);
        if (servicioSeleccionado != null) {
            servicioSeleccionado.menu();
        } else {
            JOptionPane.showMessageDialog(null, "Opci�n no disponible.");
        }
    }
}
