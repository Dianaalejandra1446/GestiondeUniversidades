package Util;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.text.NumberFormat;
import java.util.Locale;

public class Formato {
    
    // Formato para la Fecha
    private static final DateTimeFormatter FORMATO_FECHA_HORA = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    private static final Locale COLOMBIA_LOCAL = new Locale("es", "CO");

    // Constructor privado para evitar la instanciaci�n de la clase
    private Formato() {
    }

    // M�todo para formatear una fecha y hora dada como un objeto LocalDateTime
    public static String formatoFechaHora(LocalDateTime localDateTime) {
       return localDateTime != null ? localDateTime.format(FORMATO_FECHA_HORA) : "";
    }
    
    // M�todo para formatear un monto de dinero en la moneda colombiana
    public static String formatoMonedaPesos(double monto) {
       NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(COLOMBIA_LOCAL);
       return formatoMoneda.format(monto);
    }

    // M�todo para convertir un Timestamp a un objeto LocalDateTime
    public static LocalDateTime convertirTimestampFecha(Timestamp timestamp) {
       return timestamp != null ? timestamp.toLocalDateTime() : null;
    }

    // M�todo para convertir un objeto LocalDateTime a un objeto Date de SQL
    public static Date convertirLocalDateTimeSqlDate(LocalDateTime fechaFactura) {
       return fechaFactura != null ? Date.valueOf(fechaFactura.toLocalDate()) : null;
    }
}
