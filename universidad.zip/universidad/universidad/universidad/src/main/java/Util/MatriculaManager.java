package Util;

import Models.Matricula;

import java.util.List;

public class MatriculaManager {
    private List<Matricula> matriculas;
    private final String archivoJSON = "matriculas.json";

    public MatriculaManager() {
        // Cargar matr�culas existentes desde el archivo JSON
        cargarMatriculas();
    }

    public void agregarMatricula(Matricula nuevaMatricula) {
        // Agregar la nueva matr�cula a la lista
        matriculas.add(nuevaMatricula);
        // Guardar todas las matr�culas (incluyendo la nueva) en el archivo JSON
        guardarMatriculas();
    }

    private void cargarMatriculas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void guardarMatriculas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
