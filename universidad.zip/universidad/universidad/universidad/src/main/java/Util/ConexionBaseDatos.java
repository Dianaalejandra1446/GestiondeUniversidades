package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBaseDatos {
    private static String url="jdbc:mysql://RootCampus:3306/universidad";
    private static String username="root";
    private static String password="campus2024";
    private static Connection conection;


    public static Connection getInstance()throws SQLException{
        if(conection==null){
            conection=DriverManager.getConnection(url,username,password);       
        }
        return conection;
    }
}
