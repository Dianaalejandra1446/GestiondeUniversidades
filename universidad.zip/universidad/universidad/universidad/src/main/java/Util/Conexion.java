package Util;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 * Clase para establecer y cerrar la conexi�n a una base de datos MySQL.
 * Utiliza el patr�n de dise�o Singleton para garantizar una �nica instancia de la conexi�n.
 */
public class Conexion {

    // Constructor privado para evitar la creaci�n de instancias fuera de la clase.
    private Conexion() {
    }
    
    // Variable que guarda el estado de la conexi�n a la base de datos.
    private static Connection conexion;
    
    // Variable para almacenar la �nica instancia de la clase.
    private static Conexion instancia;
    
    // Variables para la configuraci�n de la conexi�n a la base de datos.
    private static final String URL = "jdbc:mysql://localhost:3306/universidad?serverTimezone=UTC";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "campus2024";
   
    /**
     * M�todo para establecer la conexi�n a la base de datos.
     * @return La conexi�n establecida.
     */
    public Connection conectar(){
        try {
            // Se carga el driver de MySQL.
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Se establece la conexi�n utilizando los datos de configuraci�n.
            conexion = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("\n====================================\n");
            System.out.println("Conexi�n Exitosa.");
            return conexion;
        } catch (Exception e) {
            // En caso de error, se muestra un mensaje de alerta.
            JOptionPane.showMessageDialog(null, "Error: no se pudo abrir la conexi�n por: "+e+"\n"
                    + "Verifique si su base de datos est� activa");
        }
        return conexion;
    }
    
    /**
     * M�todo para cerrar la conexi�n a la base de datos.
     * @throws SQLException si ocurre un error al cerrar la conexi�n.
     */
    public void cerrarConexion() throws SQLException{
        try {
            // Se cierra la conexi�n.
            conexion.close();
            System.out.println("\n====================================\n");
            System.out.println("Procediendo con la desconexi�n de la base de datos\n"
                +"Desconectando de la base de datos......");
            System.out.println("Desconectado de la base de datos");
        } catch (Exception e) {
            // En caso de error al cerrar la conexi�n, se muestra un mensaje de alerta.
            JOptionPane.showMessageDialog(null, "Error: no se pudo cerrar por: "+e);
            conexion.close();
        } finally {
            // Finally se utiliza para asegurar que la conexi�n se cierre en cualquier caso.
            conexion.close();
        }
    }
    
    /**
     * M�todo para obtener la �nica instancia de la clase Conexion utilizando el patr�n Singleton.
     * @return La �nica instancia de la clase Conexion.
     */
    public static Conexion getInstance(){
        if(instancia == null){
            instancia = new Conexion();
        }
        return instancia;
    }
}