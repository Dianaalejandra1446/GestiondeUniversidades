package Views;

import Services.*;
import Repository.*;
import javax.swing.JOptionPane;

public class ConexionFabrica {
    public Services getConexion(String opcion) {
        switch (opcion.toLowerCase()) {
            case "persona":
                return new PersonaServices();
            case "profesor":
                return new ProfesorServices();
            case "alumno":
                return new AlumnoServices();
            case "ciudad":
                return new CiudadServices();
            case "departamento":
                return new DepartamentoServices();
            case "matricula":
                return new MatriculaServices();
            case "asignatura":
                return new AsignaturaServices();
            case "cursos":
                return new CursosServices();
            case "periodo":
                return new PeriodoServices();
            case "programa":
                return new ProgramaServices();
            case "tarifa":
                return new TarifasServices();
            case "salones":
                return new SalonesServices();
            case "horario":
                return new HorarioServices();
            case "piso":
                return new PisoServices();
            case "edificio":
                return new EdificioServices();
            default:
                JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                return new ConexionVacia();
        }
    }
}
