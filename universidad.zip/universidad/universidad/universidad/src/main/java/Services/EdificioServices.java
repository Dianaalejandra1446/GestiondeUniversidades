package Services;

import Models.Edificio;
import Repository.EdificioImpl;
import Repository.Repository;
import java.util.List;
import javax.swing.JOptionPane;

public class EdificioServices implements Services<Object> {
    private static final Repository<Edificio> edificioRepository = new EdificioImpl();
    
    @Override
    public Object datos() {
        Edificio edificio = new Edificio();
        
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del edificio:");
        edificio.setNombre_edificio(nombre);
        
        return edificio;
    }
    
    @Override
    public void guardar() {
        Edificio edificio = (Edificio) datos();
        edificioRepository.guardar(edificio);
        JOptionPane.showMessageDialog(null, "Edificio guardado exitosamente.");
    }
    
    @Override
    public void modificar() {
        int idEdificioModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del edificio a modificar:"));
        Edificio edificioModificar = edificioRepository.porCodigo(idEdificioModificar);
        
        if (edificioModificar != null) {
            // Actualizar los datos del edificio
            Edificio nuevoEdificio = (Edificio) datos();
            edificioModificar.setNombre_edificio(nuevoEdificio.getNombre_edificio());
            
            edificioRepository.modificar(edificioModificar);
            JOptionPane.showMessageDialog(null, "Edificio modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El edificio con ID " + idEdificioModificar + " no existe.");
        }
    }
    
    @Override
    public void buscar() {
        int idEdificioBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del edificio a buscar:"));
        Edificio edificioBuscar = edificioRepository.porCodigo(idEdificioBuscar);
        
        if (edificioBuscar != null) {
            JOptionPane.showMessageDialog(null, "Edificio encontrado:\n" + edificioBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El edificio con ID " + idEdificioBuscar + " no existe.");
        }
    }
    
    @Override
    public void eliminar() {
        int idEdificioEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del edificio a eliminar:"));
        Edificio edificioEliminar = edificioRepository.porCodigo(idEdificioEliminar);
        
        if (edificioEliminar != null) {
            edificioRepository.eliminar(idEdificioEliminar);
            JOptionPane.showMessageDialog(null, "Edificio eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El edificio con ID " + idEdificioEliminar + " no existe.");
        }
    }
    
    @Override
    public void listar() {
        List<Edificio> edificios = edificioRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Edificios:\n");
        for (Edificio edificio : edificios) {
            stringBuilder.append(edificio.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }
    
    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU EDIFICIOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));
            
            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
