package Services;

import Models.*;
import Repository.*;
import Services.Services;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class AlumnoServices implements Services<Alumnos> {
    private static final Repository<Alumnos> alumnosRepository = new AlumnosImpl();
    private static final Repository<Persona> personaRepository = new PersonaImpl();

    @Override
    public Alumnos datos() {
        Alumnos alumno = new Alumnos();

        double num_carnet = Double.parseDouble(JOptionPane.showInputDialog("Digite el n�mero de carn� del alumno"));

        Persona persona = seleccionarPersona();
        alumno.setNum_carnet(num_carnet);
        alumno.setPersona(persona);

        return alumno;
    }

    @Override
    public void guardar() {
        Alumnos alumno = datos();
        alumnosRepository.guardar(alumno);
        JOptionPane.showMessageDialog(null, "Alumno guardado exitosamente.");
    }

    @Override
    public void modificar() {
        int idAlumnoModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del alumno a modificar:"));
        Alumnos alumnoModificar = alumnosRepository.porCodigo(idAlumnoModificar);

        if (alumnoModificar != null) {
            // Actualizar los datos del alumno
            Alumnos nuevoAlumno = datos();
            alumnoModificar.setNum_carnet(nuevoAlumno.getNum_carnet());
            alumnoModificar.setPersona(nuevoAlumno.getPersona());

            alumnosRepository.modificar(alumnoModificar);
            JOptionPane.showMessageDialog(null, "Alumno modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El alumno con ID " + idAlumnoModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idAlumnoBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del alumno a buscar:"));
        Alumnos alumnoBuscar = alumnosRepository.porCodigo(idAlumnoBuscar);

        if (alumnoBuscar != null) {
            JOptionPane.showMessageDialog(null, "Alumno encontrado:\n" + alumnoBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El alumno con ID " + idAlumnoBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idAlumnoEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del alumno a eliminar:"));
        Alumnos alumnoEliminar = alumnosRepository.porCodigo(idAlumnoEliminar);

        if (alumnoEliminar != null) {
            alumnosRepository.eliminar(idAlumnoEliminar);
            JOptionPane.showMessageDialog(null, "Alumno eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El alumno con ID " + idAlumnoEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Alumnos> alumnos = alumnosRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Alumnos:\n");
        for (Alumnos alumno : alumnos) {
            stringBuilder.append(alumno.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU ALUMNOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

    private Persona seleccionarPersona() {
        List<Persona> personas = personaRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();

        for (Persona p : personas) {
            opciones.add("ID: " + p.getId_persona() +
                    " - Nombre: " + p.getNombre_persona() +
                    " - Apellido: " + p.getApellido_persona());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione una persona: ",
                "Elige el ID de la persona",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Persona persona : personas) {
                String personaString = "ID: " + persona.getId_persona() +
                        " - Nombre: " + persona.getNombre_persona() +
                        " - Apellido: " + persona.getApellido_persona();
                if (personaString.equals(opcionSeleccionada)) {
                    return persona;
                }
            }
        }
        return null; // Si no se seleccion� ning�n curso o no se encontr� coincidencia
    }
}
