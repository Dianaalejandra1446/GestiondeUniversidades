package Services;

import Models.Departamento;
import Repository.DepartamentosImpl;
import Repository.Repository;
import java.util.List;
import javax.swing.JOptionPane;

public class DepartamentoServices implements Services {
    private static final Repository<Departamento> departamentoRepository = new DepartamentosImpl();

    @Override
    public Departamento datos() {
        String nombre_departamento = JOptionPane.showInputDialog("Digite el nombre del departamento: ");
        Departamento d = new Departamento();
        d.setNombre_departamento(nombre_departamento);
        return d; // Implementa seg�n sea necesario
    }

    @Override
    public void guardar() {
        Departamento d = datos();
        departamentoRepository.guardar(d);
        JOptionPane.showMessageDialog(null, "DATOS GUARDADOS");
    }

    @Override
    public void modificar() {
        int id_departamento = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del departamento que se va modificar: "));
        Departamento d = departamentoRepository.porCodigo(id_departamento);
        if (d != null) {
            String nombre_departamento = JOptionPane.showInputDialog("Digite el nombre del departamento: ");
            d.setNombre_departamento(nombre_departamento);
            departamentoRepository.modificar(d);
            JOptionPane.showMessageDialog(null, "DATOS MODIFICADOS \n" +
                    "Codigo departamento: \n" + d.getId_departamento() + "Nombre departamento: \n" + d.getNombre_departamento());
        } else {
            JOptionPane.showMessageDialog(null, "Departamento no encontrado");
        }
    }

    @Override
    public void buscar() {
        int id_departamento = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del departamento que se va a buscar: "));
        Departamento d = departamentoRepository.porCodigo(id_departamento);
        if (d != null) {
            JOptionPane.showMessageDialog(null, "ID ENCONTRADO: \n" +
                    "Codigo departamento: " + d.getId_departamento() + "\n Nombre:" + d.getNombre_departamento());
        } else {
            JOptionPane.showMessageDialog(null, "Departamento no encontrado");
        }
    }

    @Override
    public void eliminar() {
        int id_departamento = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del departamento que se va eliminar: "));
        Departamento d = departamentoRepository.porCodigo(id_departamento);
        if (d != null) {
            departamentoRepository.eliminar(id_departamento);
            JOptionPane.showMessageDialog(null, "DATOS ELIMINADOS \n" +
                    "Codigo departamento: " + d.getId_departamento() + "\n Nombre:" + d.getNombre_departamento());
        } else {
            JOptionPane.showMessageDialog(null, "Departamento no encontrado");
        }
    }

    @Override
    public void listar() {
        // Obtener la lista de departamentos del repositorio
        List<Departamento> departamentos = departamentoRepository.listar();

        // Verificar si hay departamentos en la lista
        if (departamentos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay departamentos registrados.");
        } else {
            // Construir un mensaje con la lista de departamentos
            StringBuilder mensaje = new StringBuilder("DEPARTAMENTOS:\n");
            for (Departamento d : departamentos) {
                mensaje.append("ID: ").append(d.getId_departamento()).append(", Nombre: ").append(d.getNombre_departamento()).append("\n");
            }
            // Mostrar el mensaje con la lista de departamentos
            JOptionPane.showMessageDialog(null, mensaje.toString());
        }
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU DEPARTAMENTO*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
