package Services;

import Models.Periodo;
import Repository.PeriodoImpl;
import Repository.Repository;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PeriodoServices implements Services<Object> {
    private static final Repository<Periodo> periodoRepository = new PeriodoImpl();

    @Override
    public Object datos() {
        Periodo periodo = new Periodo();

        String nombre_periodo = JOptionPane.showInputDialog("Ingrese el nombre del periodo:");
        int codigo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el c�digo del periodo:"));
        int anio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el a�o del periodo:"));
        String semestre_correspondiente = JOptionPane.showInputDialog("Ingrese el semestre correspondiente:");
        int credito_periodo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el n�mero de cr�ditos del periodo:"));

        periodo.setNombre_periodo(nombre_periodo);
        periodo.setCodigo(codigo);
        periodo.setAnio(anio);
        periodo.setSemestre_correspondiente(semestre_correspondiente);
        periodo.setCredito_periodo(credito_periodo);

        return periodo;
    }

    @Override
    public void guardar() {
        Periodo periodo = (Periodo) datos();
        periodoRepository.guardar(periodo);
        JOptionPane.showMessageDialog(null, "Periodo guardado exitosamente.");
    }

    @Override
    public void modificar() {
        int idPeriodoModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del periodo a modificar:"));
        Periodo periodoModificar = periodoRepository.porCodigo(idPeriodoModificar);

        if (periodoModificar != null) {
            Periodo nuevoPeriodo = (Periodo) datos();
            nuevoPeriodo.setId_periodo(periodoModificar.getId_periodo());
            periodoRepository.modificar(nuevoPeriodo);
            JOptionPane.showMessageDialog(null, "Periodo modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El periodo con ID " + idPeriodoModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idPeriodoBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del periodo a buscar:"));
        Periodo periodoBuscar = periodoRepository.porCodigo(idPeriodoBuscar);

        if (periodoBuscar != null) {
            JOptionPane.showMessageDialog(null, "Periodo encontrado:\n" + periodoBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El periodo con ID " + idPeriodoBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idPeriodoEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del periodo a eliminar:"));
        Periodo periodoEliminar = periodoRepository.porCodigo(idPeriodoEliminar);

        if (periodoEliminar != null) {
            periodoRepository.eliminar(idPeriodoEliminar);
            JOptionPane.showMessageDialog(null, "Periodo eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El periodo con ID " + idPeriodoEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Periodo> periodos = periodoRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Periodos:\n");
        for (Periodo periodo : periodos) {
            stringBuilder.append(periodo.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU PERIODOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
