package Services;

import Models.Periodo;
import Models.Programa;
import Models.Tarifas;
import Repository.PeriodoImpl;
import Repository.ProgramaImpl;
import Repository.Repository;
import Repository.TarifasImpl;
import Services.Services;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TarifasServices implements Services<Object> {
    private static final Repository<Tarifas> tarifasRepository = new TarifasImpl();
    private static final Repository<Periodo> periodoRepository = new PeriodoImpl();
    private static final Repository<Programa> programaRepository = new ProgramaImpl();
    
    @Override
    public Object datos() {
        Tarifas t = new Tarifas();
        
        double valor_credito = Double.parseDouble(JOptionPane.showInputDialog("Digite su numero de credito"));
        
        Periodo periodo = seleccionarPeriodo();
        t.setPeriodo(periodo);
        
        Programa programa = seleccionarPrograma();
        t.setPrograma(programa);
        
        return t;
    }

    @Override
    public void guardar() {
        Tarifas tarifa = (Tarifas) datos();
        tarifasRepository.guardar(tarifa);
        JOptionPane.showMessageDialog(null, "Tarifa guardada exitosamente.");
    }

@Override
public void modificar() {
    int idTarifaModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la tarifa a modificar:"));
    Tarifas tarifaModificar = tarifasRepository.porCodigo(idTarifaModificar);
    
    if (tarifaModificar != null) {
        // Actualizar los datos de la tarifa
        Tarifas nuevaTarifa = (Tarifas) datos();
        tarifaModificar.setValor_credito(nuevaTarifa.getValor_credito());
        tarifaModificar.setPeriodo(nuevaTarifa.getPeriodo());
        tarifaModificar.setPrograma(nuevaTarifa.getPrograma());
        
        tarifasRepository.modificar(tarifaModificar);
        JOptionPane.showMessageDialog(null, "Tarifa modificada exitosamente.");
    } else {
        JOptionPane.showMessageDialog(null, "La tarifa con ID " + idTarifaModificar + " no existe.");
    }
}


    @Override
    public void buscar() {
        int idTarifaBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la tarifa a buscar:"));
        Tarifas tarifaBuscar = tarifasRepository.porCodigo(idTarifaBuscar);
        
        if (tarifaBuscar != null) {
            JOptionPane.showMessageDialog(null, "Tarifa encontrada:\n" + tarifaBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "La tarifa con ID " + idTarifaBuscar + " no existe.");
        }
    }

@Override
public void eliminar() {
    int idTarifaEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la tarifa a eliminar:"));
    Tarifas tarifaEliminar = tarifasRepository.porCodigo(idTarifaEliminar);
    
    if (tarifaEliminar != null) {
        tarifasRepository.eliminar(idTarifaEliminar);
        JOptionPane.showMessageDialog(null, "Tarifa eliminada exitosamente.");
    } else {
        JOptionPane.showMessageDialog(null, "La tarifa con ID " + idTarifaEliminar + " no existe.");
    }
}

    @Override
    public void listar() {
        List<Tarifas> tarifas = tarifasRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Tarifas:\n");
        for (Tarifas tarifa : tarifas) {
            stringBuilder.append(tarifa.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU TARIFAS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

    private Periodo seleccionarPeriodo() {
        List<Periodo> periodos = periodoRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Periodo p : periodos) {
            opciones.add("ID: " + p.getId_periodo() +
                         " - Nombre: " + p.getNombre_periodo() + 
                         " - Codigo: " + p.getCodigo() + 
                         " - A�o: " + p.getAnio() +
                         " - Semestre correspondiente: " + p.getSemestre_correspondiente() +
                         " - Creditos periodo: " + p.getCredito_periodo());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un periodo: ",
                "Elige el id de tu periodo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);
        
        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Periodo per : periodos) {
                String periodoString = "ID: " + per.getId_periodo() +
                                        " - Nombre: " + per.getNombre_periodo() + 
                                        " - Codigo: " + per.getCodigo() + 
                                        " - A�o: " + per.getAnio() +
                                        " - Semestre correspondiente: " + per.getSemestre_correspondiente() +
                                        " - Creditos periodo: " + per.getCredito_periodo();
                if (periodoString.equals(opcionSeleccionada)) {
                    return per;
                }
            }
        }
        
        return null; // Si no se seleccion� ning�n periodo o no se encontr� coincidencia
    }
    

    private Programa seleccionarPrograma() {
        List<Programa> programas = programaRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Programa p : programas) {
            opciones.add("ID: " + p.getId_programa() +
                        " - Nombre: " + p.getNombre_programa()+
                        " -Nivel programa: "+ p.getNivel_programa()+
                        " -Creditos programa: "+ p.getCreditos_programa());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un programa: ",
                "Elige el id de tu programa",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);
        
        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Programa pro : programas) {
                String programaString = "ID: " + pro.getId_programa() +
                                        " - Nombre: " + pro.getNombre_programa()+
                                        " -Nivel programa: "+pro.getNivel_programa()+
                                        " -Creditos programa: "+pro.getCreditos_programa();
                if (programaString.equals(opcionSeleccionada)) {
                    return pro;
                }
            }
        }
        
        return null; // Si no se seleccion� ning�n programa o no se encontr� coincidencia
    }
}
