package Services;

import Models.*;
import Repository.*;
import Services.Services;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class HorarioServices implements Services<Object> {
    private static final Repository<Horario> horarioRepository = new HorarioImpl();
    private static final Repository<Asignatura> asignaturaRepository = new AsignaturaImpl();
    private static final Repository<Salones> salonRepository = new SalonesImpl();
    private static int ultimoIdHorario = 0;

    public HorarioServices() {
        // Obtener el �ltimo ID de horario al iniciar el servicio
        List<Horario> horarios = horarioRepository.listar();
        if (!horarios.isEmpty()) {
            ultimoIdHorario = horarios.get(horarios.size() - 1).getId_horario();
        }
    }

    @Override
    public Object datos() {
        Asignatura asignatura = seleccionarAsignatura();
        Salones salon = seleccionarSalon();
        String dia = JOptionPane.showInputDialog("Ingrese el d�a:");
        String horaInicio = JOptionPane.showInputDialog("Ingrese la hora de inicio (formato HH:MM):");
        String horaFin = JOptionPane.showInputDialog("Ingrese la hora de fin (formato HH:MM):");

        return new Horario(++ultimoIdHorario, dia, horaInicio, horaFin, salon, asignatura);
    }

    @Override
    public void guardar() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "�Desea generar un nuevo horario?", "Confirmar Horario", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            Horario horario = (Horario) datos();
            horarioRepository.guardar(horario);
            JOptionPane.showMessageDialog(null, "Horario guardado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se gener� ning�n horario.");
        }
    }

    @Override
    public void modificar() {
        int idHorarioModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del horario a modificar:"));
        Horario horarioModificar = horarioRepository.porCodigo(idHorarioModificar);

        if (horarioModificar != null) {
            Horario nuevoHorario = (Horario) datos();
            horarioModificar.setAsignatura(nuevoHorario.getAsignatura());
            horarioModificar.setSalon(nuevoHorario.getSalon());
            horarioModificar.setDia(nuevoHorario.getDia());
            horarioModificar.setHora_inicio(nuevoHorario.getHora_inicio());
            horarioModificar.setHora_fin(nuevoHorario.getHora_fin());
            
            horarioRepository.modificar(horarioModificar);
            JOptionPane.showMessageDialog(null, "Horario modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El horario con ID " + idHorarioModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idHorarioBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del horario a buscar:"));
        Horario horarioBuscar = horarioRepository.porCodigo(idHorarioBuscar);
        
        if (horarioBuscar != null) {
            JOptionPane.showMessageDialog(null, "Horario encontrado:\n" + horarioBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El horario con ID " + idHorarioBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idHorarioEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del horario a eliminar:"));
        Horario horarioEliminar = horarioRepository.porCodigo(idHorarioEliminar);
        
        if (horarioEliminar != null) {
            horarioRepository.eliminar(idHorarioEliminar);
            JOptionPane.showMessageDialog(null, "Horario eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El horario con ID " + idHorarioEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Horario> horarios = horarioRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Horarios:\n");
        for (Horario horario : horarios) {
            stringBuilder.append(horario.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU HORARIOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

    private Asignatura seleccionarAsignatura() {
        List<Asignatura> asignaturas = asignaturaRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Asignatura a : asignaturas) {
            opciones.add("ID: " + a.getId_asignatura() + " - Nombre: " + a.getNombre_combinado());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione una asignatura: ",
                "Elige el ID de la asignatura",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) {
            int idSeleccionado = Integer.parseInt(opcionSeleccionada.split(" ")[1]); // Obtener el ID de la asignatura seleccionada
            for (Asignatura asignatura : asignaturas) {
                if (asignatura.getId_asignatura() == idSeleccionado) {
                    return asignatura;
                }
            }
        }
        
        return null;
    }

    private Salones seleccionarSalon() {
        List<Salones> salones = salonRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Salones s : salones) {
            opciones.add("ID: " + s.getId_salon() + " - Nombre: " + s.getNumero_identificacion());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un sal�n: ",
                "Elige el ID del sal�n",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) {
            int idSeleccionado = Integer.parseInt(opcionSeleccionada.split(" ")[1]); // Obtener el ID del sal�n seleccionado
            for (Salones salon : salones) {
                if (salon.getId_salon() == idSeleccionado) {
                    return salon;
                }
            }
        }
        
        return null;
    }
}
