package Services;

import Models.Piso;
import Repository.PisoImpl;
import Repository.Repository;
import java.util.List;
import javax.swing.JOptionPane;

public class PisoServices implements Services<Object> {
    private static final Repository<Piso> pisoRepository = new PisoImpl();
    
    @Override
    public Object datos() {
        Piso piso = new Piso();
        
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del piso:");
        piso.setNombre_piso(nombre);
        
        return piso;
    }
    
    @Override
    public void guardar() {
        Piso piso = (Piso) datos();
        pisoRepository.guardar(piso);
        JOptionPane.showMessageDialog(null, "Piso guardado exitosamente.");
    }
    
    @Override
    public void modificar() {
        int idPisoModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del piso a modificar:"));
        Piso pisoModificar = pisoRepository.porCodigo(idPisoModificar);
        
        if (pisoModificar != null) {
            // Actualizar los datos del piso
            Piso nuevoPiso = (Piso) datos();
            pisoModificar.setNombre_piso(nuevoPiso.getNombre_piso());
            
            pisoRepository.modificar(pisoModificar);
            JOptionPane.showMessageDialog(null, "Piso modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El piso con ID " + idPisoModificar + " no existe.");
        }
    }
    
    @Override
    public void buscar() {
        int idPisoBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del piso a buscar:"));
        Piso pisoBuscar = pisoRepository.porCodigo(idPisoBuscar);
        
        if (pisoBuscar != null) {
            JOptionPane.showMessageDialog(null, "Piso encontrado:\n" + pisoBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El piso con ID " + idPisoBuscar + " no existe.");
        }
    }
    
    @Override
    public void eliminar() {
        int idPisoEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del piso a eliminar:"));
        Piso pisoEliminar = pisoRepository.porCodigo(idPisoEliminar);
        
        if (pisoEliminar != null) {
            pisoRepository.eliminar(idPisoEliminar);
            JOptionPane.showMessageDialog(null, "Piso eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El piso con ID " + idPisoEliminar + " no existe.");
        }
    }
    
    @Override
    public void listar() {
        List<Piso> pisos = pisoRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Pisos:\n");
        for (Piso piso : pisos) {
            stringBuilder.append(piso.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }
    
    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU PISOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));
            
            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
