package Services;

import javax.swing.JOptionPane;

public class ConexionVacia implements Services {

    
    @Override
    public Object datos() {
        JOptionPane.showMessageDialog(null, "No se pudo guardar datos");
        return null;
    }

    @Override
    public void guardar() {
        JOptionPane.showMessageDialog(null, "No se pudo guardar datos");

    }

    @Override
    public void modificar() {
        JOptionPane.showMessageDialog(null, "No se pudo modificar datos");

    }

    @Override
    public void buscar() {
        JOptionPane.showMessageDialog(null, "No se pudo buscar datos");

    }

    @Override
    public void eliminar() {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar datos");

    }

    @Override
    public void listar() {
        JOptionPane.showMessageDialog(null, "No se pudo listar datos");

    }

    @Override
    public void menu() {
        JOptionPane.showMessageDialog(null, "No se pudo acceder al menu");

    }
    
}
