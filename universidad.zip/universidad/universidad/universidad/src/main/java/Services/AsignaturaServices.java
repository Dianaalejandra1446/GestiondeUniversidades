package Services;
import Models.Asignatura;
import Models.Cursos;
import Models.Periodo;
import Models.Programa;
import Models.Profesor;
import Repository.AsignaturaImpl;
import Repository.CursosImpl;
import Repository.PeriodoImpl;
import Repository.ProgramaImpl;
import Repository.ProfesorImpl;
import Repository.Repository;
import Services.Services;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class AsignaturaServices implements Services {

    private static final Repository<Asignatura> asignaturaRepository = new AsignaturaImpl();
    private static final Repository<Periodo> periodoRepository = new PeriodoImpl();
    private static final Repository<Profesor> profesorRepository = new ProfesorImpl();
    private static final Repository<Programa> programaRepository = new ProgramaImpl();
    private static final Repository<Cursos> cursosRepository = new CursosImpl();

    @Override
    public Object datos() {
        Asignatura asignatura = new Asignatura();
        
        asignatura.setNombre_combinado(JOptionPane.showInputDialog("Ingrese el nombre combinado de la asignatura:"));
        asignatura.setCantidad_creditos(Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de cr�ditos de la asignatura:")));
        asignatura.setCupos(Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de cupos disponibles:")));
        // Obtener los objetos relacionados
        asignatura.setPeriodo(obtenerPeriodo());
        asignatura.setProfesor(obtenerProfesor());
        asignatura.setPrograma(obtenerPrograma());
        asignatura.setCursos(obtenerCursos());
        
        return asignatura;
    }

    @Override
    public void guardar() {
        Asignatura asignatura = (Asignatura) datos();
        asignaturaRepository.guardar(asignatura);
        JOptionPane.showMessageDialog(null, "Asignatura guardada exitosamente.");
    }

    @Override
    public void modificar() {
        int idAsignaturaModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la asignatura a modificar:"));
        Asignatura asignaturaModificar = asignaturaRepository.porCodigo(idAsignaturaModificar);
        
        if (asignaturaModificar != null) {
            // Actualizar los datos de la asignatura
            Asignatura nuevaAsignatura = (Asignatura) datos();
            asignaturaModificar.setNombre_combinado(nuevaAsignatura.getNombre_combinado());
            asignaturaModificar.setCantidad_creditos(nuevaAsignatura.getCantidad_creditos());
            asignaturaModificar.setCupos(nuevaAsignatura.getCupos());
            asignaturaModificar.setPeriodo(nuevaAsignatura.getPeriodo());
            asignaturaModificar.setProfesor(nuevaAsignatura.getProfesor());
            asignaturaModificar.setPrograma(nuevaAsignatura.getPrograma());
            asignaturaModificar.setCursos(nuevaAsignatura.getCursos());
            
            asignaturaRepository.modificar(asignaturaModificar);
            JOptionPane.showMessageDialog(null, "Asignatura modificada exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "La asignatura con ID " + idAsignaturaModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idAsignaturaBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la asignatura a buscar:"));
        Asignatura asignaturaBuscar = asignaturaRepository.porCodigo(idAsignaturaBuscar);
        
        if (asignaturaBuscar != null) {
            JOptionPane.showMessageDialog(null, "Asignatura encontrada:\n" + asignaturaBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "La asignatura con ID " + idAsignaturaBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idAsignaturaEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la asignatura a eliminar:"));
        Asignatura asignaturaEliminar = asignaturaRepository.porCodigo(idAsignaturaEliminar);
        
        if (asignaturaEliminar != null) {
            asignaturaRepository.eliminar(idAsignaturaEliminar);
            JOptionPane.showMessageDialog(null, "Asignatura eliminada exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "La asignatura con ID " + idAsignaturaEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Asignatura> asignaturas = asignaturaRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Asignaturas:\n");
        for (Asignatura asignatura : asignaturas) {
            stringBuilder.append(asignatura.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU ASIGNATURA*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

    private Periodo obtenerPeriodo() {
        List<Periodo> periodos = periodoRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Periodo p : periodos) {
            opciones.add("ID: " + p.getId_periodo() +
                         " - Nombre: " + p.getNombre_periodo() + 
                         " - Codigo: " + p.getCodigo() + 
                         " - A�o: " + p.getAnio() +
                         " - Semestre correspondiente: " + p.getSemestre_correspondiente() +
                         " - Creditos periodo: " + p.getCredito_periodo());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un periodo: ",
                "Elige el id de tu periodo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);
        
        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Periodo per : periodos) {
                String periodoString = "ID: " + per.getId_periodo() +
                                        " - Nombre: " + per.getNombre_periodo() + 
                                        " - Codigo: " + per.getCodigo() + 
                                        " - A�o: " + per.getAnio() +
                                        " - Semestre correspondiente: " + per.getSemestre_correspondiente() +
                                        " - Creditos periodo: " + per.getCredito_periodo();
                if (periodoString.equals(opcionSeleccionada)) {
                    return per;
                }
            }
        }
        
        return null; // Si no se seleccion� ning�n periodo o no se encontr� coincidencia
    }

    private Profesor obtenerProfesor() {
        List<Profesor> profesores = profesorRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();

        for (Profesor p : profesores) {
            opciones.add("ID Profesor: " + p.getId_profesor() +
                         " - ID Persona: " + p.getPersona().getId_persona() + 
                         " - ID Departamento: " + p.getDepartamentos().getId_departamento());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un profesor: ",
                "Elige el id de tu profesor",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Profesor profe : profesores) {
                String profesorString = "ID Profesor: " + profe.getId_profesor() +
                                        " - ID Persona: " + profe.getPersona().getId_persona() + 
                                        " - ID Departamento: " + profe.getDepartamentos().getId_departamento();
                if (profesorString.equals(opcionSeleccionada)) {
                    return profe;
                }
            }
        }

        return null; // Si no se seleccion� ning�n profesor o no se encontr� coincidencia
    }


    private Programa obtenerPrograma() {
        List<Programa> programas = programaRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Programa p : programas) {
            opciones.add("ID: " + p.getId_programa() +
                         " - Nombre: " + p.getNombre_programa() + 
                         " - Nivel: " + p.getNivel_programa());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un programa: ",
                "Elige el id de tu programa",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);
        
        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Programa programa : programas) {
                String programaString = "ID: " + programa.getId_programa() +
                                         " - Nombre: " + programa.getNombre_programa() + 
                                         " - Nivel: " + programa.getNivel_programa();
                if (programaString.equals(opcionSeleccionada)) {
                    return programa;
                }
            }
        }
        
        return null; // Si no se seleccion� ning�n programa o no se encontr� coincidencia
    }

    private Cursos obtenerCursos() {
        List<Cursos> cursos = cursosRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();
        
        for (Cursos c : cursos) {
            opciones.add("ID: " + c.getId_curso() +
                         " - Nombre: " + c.getNombre_curso());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un curso: ",
                "Elige el id de tu curso",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);
        
        if (opcionSeleccionada != null) { // Verificar que se haya seleccionado algo
            for (Cursos curso : cursos) {
                String cursoString = "ID: " + curso.getId_curso() +
                                     " - Nombre: " + curso.getNombre_curso();
                if (cursoString.equals(opcionSeleccionada)) {
                    return curso;
                }
            }
        }
        
        return null; // Si no se seleccion� ning�n curso o no se encontr� coincidencia
    }
}
