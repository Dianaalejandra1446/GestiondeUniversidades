package Services; 

import Models.*;
import Repository.*;
import Services.Services;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SalonesServices implements Services<Object> {
    private static final Repository<Salones> salonRepository = new SalonesImpl();
    private static int ultimoIdSalon = 0;

    public SalonesServices() {
        // Obtener el �ltimo ID de sal�n al iniciar el servicio
        List<Salones> salones = salonRepository.listar();
        if (!salones.isEmpty()) {
            ultimoIdSalon = salones.get(salones.size() - 1).getId_salon();
        }
    }

    @Override
    public Object datos() {
        double capacidad = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la capacidad del sal�n:"));
        int totalCupos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el total de cupos del sal�n:"));
        double numeroIdentificacion = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el n�mero de identificaci�n del sal�n:"));

        return new Salones(++ultimoIdSalon, capacidad, totalCupos, numeroIdentificacion, null, null); // Edificio y Piso se asignar�n posteriormente
    }

    @Override
    public void guardar() {
        int confirmacion = JOptionPane.showConfirmDialog(null, "�Desea generar un nuevo sal�n?", "Confirmar Sal�n", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            Salones salon = (Salones) datos();
            salonRepository.guardar(salon);
            JOptionPane.showMessageDialog(null, "Sal�n guardado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se gener� ning�n sal�n.");
        }
    }

    @Override
    public void modificar() {
        int idSalonModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del sal�n a modificar:"));
        Salones salonModificar = salonRepository.porCodigo(idSalonModificar);

        if (salonModificar != null) {
            Salones nuevoSalon = (Salones) datos();
            salonModificar.setCapacidad(nuevoSalon.getCapacidad());
            salonModificar.setTotal_cupos(nuevoSalon.getTotal_cupos());
            salonModificar.setNumero_identificacion(nuevoSalon.getNumero_identificacion());
            
            salonRepository.modificar(salonModificar);
            JOptionPane.showMessageDialog(null, "Sal�n modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El sal�n con ID " + idSalonModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idSalonBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del sal�n a buscar:"));
        Salones salonBuscar = salonRepository.porCodigo(idSalonBuscar);
        
        if (salonBuscar != null) {
            JOptionPane.showMessageDialog(null, "Sal�n encontrado:\n" + salonBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El sal�n con ID " + idSalonBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idSalonEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del sal�n a eliminar:"));
        Salones salonEliminar = salonRepository.porCodigo(idSalonEliminar);
        
        if (salonEliminar != null) {
            salonRepository.eliminar(idSalonEliminar);
            JOptionPane.showMessageDialog(null, "Sal�n eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El sal�n con ID " + idSalonEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Salones> salones = salonRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Salones:\n");
        for (Salones salon : salones) {
            stringBuilder.append(salon.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU SALONES*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
