package Services;

import Models.*;
import Repository.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class MatriculaServices implements Services<Matricula> {
    private final Repository<Matricula> matriculaRepository = new MatriculaImpl();
    private final Repository<Alumnos> alumnosRepository = new AlumnosImpl();
    private final Repository<Asignatura> asignaturaRepository = new AsignaturaImpl();
    private int ultimoIdMatricula = 0;

    public MatriculaServices() {
        List<Matricula> matriculas = matriculaRepository.listar();
        if (!matriculas.isEmpty()) {
            ultimoIdMatricula = matriculas.get(matriculas.size() - 1).getId_matricula();
        }
    }

    @Override
    public Matricula datos() {
        Alumnos alumno = seleccionarAlumno();
        
        Asignatura asignatura = seleccionarAsignatura();
        return new Matricula(++ultimoIdMatricula, alumno, asignatura);
    }

    @Override
    public void guardar() {
        try {
            int confirmacion = JOptionPane.showConfirmDialog(null, "�Desea generar una nueva matr�cula?", "Confirmar Matr�cula", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                Matricula matricula = datos();
                matriculaRepository.guardar(matricula);
                JOptionPane.showMessageDialog(null, "Matr�cula guardada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se gener� ninguna matr�cula.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Entrada inv�lida.");
        }
    }

    @Override
    public void modificar() {
        try {
            int idMatriculaModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la matr�cula a modificar:"));
            Matricula matriculaModificar = matriculaRepository.porCodigo(idMatriculaModificar);

            if (matriculaModificar != null) {
                Matricula nuevaMatricula = datos();
                matriculaModificar.setAlumno(nuevaMatricula.getAlumno());
                matriculaModificar.setAsignatura(nuevaMatricula.getAsignatura());

                matriculaRepository.modificar(matriculaModificar);
                JOptionPane.showMessageDialog(null, "Matr�cula modificada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "La matr�cula con ID " + idMatriculaModificar + " no existe.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Entrada inv�lida.");
        }
    }

    @Override
    public void buscar() {
        try {
            int idMatriculaBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la matr�cula a buscar:"));
            Matricula matriculaBuscar = matriculaRepository.porCodigo(idMatriculaBuscar);

            if (matriculaBuscar != null) {
                JOptionPane.showMessageDialog(null, "Matr�cula encontrada:\n" + matriculaBuscar.toString());
            } else {
                JOptionPane.showMessageDialog(null, "La matr�cula con ID " + idMatriculaBuscar + " no existe.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Entrada inv�lida.");
        }
    }

    @Override
    public void eliminar() {
        try {
            int idMatriculaEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID de la matr�cula a eliminar:"));
            Matricula matriculaEliminar = matriculaRepository.porCodigo(idMatriculaEliminar);

            if (matriculaEliminar != null) {
                matriculaRepository.eliminar(idMatriculaEliminar);
                JOptionPane.showMessageDialog(null, "Matr�cula eliminada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "La matr�cula con ID " + idMatriculaEliminar + " no existe.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Entrada inv�lida.");
        }
    }

    @Override
    public void listar() {
        List<Matricula> matriculas = matriculaRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Matr�culas:\n");
        for (Matricula matricula : matriculas) {
            stringBuilder.append(matricula.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU MATR�CULAS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
    private Asignatura seleccionarAsignatura() {
        List<Asignatura> asignaturas = asignaturaRepository.listar();

        if (asignaturas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay asignaturas para seleccionar");
            return null;
        }

        ArrayList<String> opcionesAsignaturas = new ArrayList<>();

        for (Asignatura asignatura : asignaturas) {
            opcionesAsignaturas.add(String.format("ID: %d - Nombre: %s - Cr�ditos: %d - Cupos: %d - ID Periodo: %d - ID Profesor: %d - ID Programa: %d - ID Curso: %d",
                    asignatura.getId_asignatura(), asignatura.getNombre_combinado(), asignatura.getCantidad_creditos(),
                    asignatura.getCupos(), asignatura.getPeriodo().getId_periodo(), asignatura.getProfesor().getId_profesor(),
                    asignatura.getPrograma().getId_programa(), asignatura.getCursos().getId_curso()));
        }

        String[] opcionesArray = opcionesAsignaturas.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione una asignatura: ",
                "Elige el ID de la asignatura",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) {
            int idSeleccionado = Integer.parseInt(opcionSeleccionada.split(" - ")[0]); // Obtener el ID de la asignatura seleccionada
            for (Asignatura asignatura : asignaturas) {
                if (asignatura.getId_asignatura() == idSeleccionado) {
                    return asignatura;
                }
            }
        }

        return null;
    }

    private Alumnos seleccionarAlumno() {
        List<Alumnos> alumnos = alumnosRepository.listar();

        ArrayList<String> opcionesAlumnos = new ArrayList<>();

        for (Alumnos alumno : alumnos) {
            String infoAlumno = alumno.getId_alumno() + " - " + alumno.getNum_carnet();
            if (alumno.getPersona() != null) {
                // Aqu� asumimos que la clase Persona tiene un m�todo isEmpty que define cuando una persona est� vac�a.
                if (!alumno.getPersona().isEmpty()) {
                    infoAlumno += " - " + alumno.getPersona().getId_persona();
                } else {
                    infoAlumno += " - N/A";
                }
            } else {
                infoAlumno += " - N/A";
            }
            opcionesAlumnos.add(infoAlumno);
        }

        String[] opcionesArray = opcionesAlumnos.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione un alumno: ",
                "Elige el ID del alumno",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        if (opcionSeleccionada != null) {
            int idSeleccionado = Integer.parseInt(opcionSeleccionada.split(" - ")[0]); // Obtener el ID del alumno seleccionado
            for (Alumnos alumno : alumnos) {
                if (alumno.getId_alumno() == idSeleccionado) {
                    return alumno;
                }
            }
        }

        return null;
    }



}
