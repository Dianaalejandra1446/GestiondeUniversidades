package Services;

import Models.Ciudad;
import Models.Persona;
import Repository.CiudadImpl;
import Repository.PersonaImpl;
import Repository.Repository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PersonaServices implements Services<Object> {
    private static final Repository<Persona> personaRepository = new PersonaImpl();
    private static final Repository<Ciudad> ciudadRepository = new CiudadImpl();

    @Override
    public Persona datos() {
        Persona p = new Persona();

        String tipo_documento = JOptionPane.showInputDialog("Digite el tipo de documento: ");
        p.setTipo_documento_persona(tipo_documento);

        int num_documento = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero de documento: "));
        p.setNumero_documento_persona(num_documento);

        String nombre_persona = JOptionPane.showInputDialog("Ingrese el nombre de la persona: ");
        p.setNombre_persona(nombre_persona);

        String apellido_persona = JOptionPane.showInputDialog("Ingrese el apellido de la persona: ");
        p.setApellido_persona(apellido_persona);

        String numero_telefono_persona = JOptionPane.showInputDialog("Ingrese el numero de telefono de la persona: ");
        p.setNumero_telefono_persona(numero_telefono_persona);

        String direccion_persona = JOptionPane.showInputDialog("Ingrese la direccion de la persona:  ");
        p.setDireccion_persona(direccion_persona);

        LocalDate fecha_nacimiento_persona = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de nacimiento en los formatos yyyy-mm-dd: "));
        p.setFecha_nacimiento_persona(fecha_nacimiento_persona);

        String sexo_persona = JOptionPane.showInputDialog("Ingrese el sexo de la persona F o M: ");
        p.setSexo_persona(sexo_persona);

        Ciudad ciudad = seleccionarCiudad();
        p.setCiudad_persona(ciudad);

        return p;
    }

    @Override
    public void guardar() {
        Persona p = datos();
        personaRepository.guardar(p);
        JOptionPane.showMessageDialog(null, "DATOS GUARDADOS:\n" + p);
    }

    @Override
    public void modificar() {
        int id_persona = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la persona que se va modificar: "));
        Persona p = personaRepository.porCodigo(id_persona);

        if (p != null) {
            Persona nuevaInformacion = datos();
            nuevaInformacion.setId_persona(id_persona);
            personaRepository.modificar(nuevaInformacion);
            JOptionPane.showMessageDialog(null, "DATOS MODIFICADOS:\n" + nuevaInformacion);
        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }

    @Override
    public void buscar() {
        int id_persona = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la persona que se va a buscar: "));
        Persona p = personaRepository.porCodigo(id_persona);

        if (p != null) {
            JOptionPane.showMessageDialog(null, "PERSONA ENCONTRADA:\n" + p);
        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }

    @Override
    public void eliminar() {
        int id_persona = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la persona que se va eliminar: "));
        Persona p = personaRepository.porCodigo(id_persona);

        if (p != null) {
            personaRepository.eliminar(id_persona);
            JOptionPane.showMessageDialog(null, "DATOS ELIMINADOS:\n" + p);
        } else {
            JOptionPane.showMessageDialog(null, "Persona no encontrada");
        }
    }

    @Override
    public void listar() {
        List<Persona> personas = personaRepository.listar();

        if (personas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay personas registradas.");
        } else {
            StringBuilder mensaje = new StringBuilder("PERSONAS:\n");
            for (Persona p : personas) {
                mensaje.append(p).append("\n");
            }
            JOptionPane.showMessageDialog(null, mensaje.toString());
        }
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU PERSONA*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

private Ciudad seleccionarCiudad() {
    List<Ciudad> ciudades = ciudadRepository.listar();
    
    if (ciudades.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay ciudades disponibles para seleccionar.");
        // Puedes devolver un valor predeterminado o lanzar una excepci�n seg�n tu l�gica de manejo de errores.
        // En este ejemplo, devolveremos null.
        return null;
    }

    ArrayList<String> nombres_ciudades = new ArrayList<>();
    for (Ciudad c : ciudades) {
        nombres_ciudades.add(c.getNombre_cuidad());
    }

    String[] opciones = nombres_ciudades.toArray(new String[0]);
    String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
            "Seleccione una ciudad: ",
            "Elige tu ciudad",
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]);

    for (Ciudad c : ciudades) {
        if (c.getNombre_cuidad().equals(opcionSeleccionada)) {
            return c;
        }
    }

    // Si no se encuentra la ciudad seleccionada por alguna raz�n, puedes manejarlo seg�n tu l�gica.
    // En este ejemplo, simplemente devolvemos null.
    return null;
}

}

