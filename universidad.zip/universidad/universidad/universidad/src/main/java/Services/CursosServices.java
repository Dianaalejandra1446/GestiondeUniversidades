package Services;

import Models.*;
import Repository.*;
import Services.Services;
import java.util.List;
import javax.swing.JOptionPane;

public class CursosServices implements Services<Cursos> {
    private static final Repository<Cursos> cursosRepository = new CursosImpl();

    @Override
    public Cursos datos() {
        Cursos curso = new Cursos();

        String nombre_curso = JOptionPane.showInputDialog("Ingrese el nombre del curso:");
        String temas = JOptionPane.showInputDialog("Ingrese los temas del curso:");
        String competencias = JOptionPane.showInputDialog("Ingrese las competencias del curso:");

        curso.setNombre_curso(nombre_curso);
        curso.setTemas(temas);
        curso.setCompetencias(competencias);

        return curso;
    }

    @Override
    public void guardar() {
        Cursos curso = datos();
        cursosRepository.guardar(curso);
        JOptionPane.showMessageDialog(null, "Curso guardado exitosamente.");
    }

    @Override
    public void modificar() {
        int idCursoModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del curso a modificar:"));
        Cursos cursoModificar = cursosRepository.porCodigo(idCursoModificar);

        if (cursoModificar != null) {
            // Actualizar los datos del curso
            Cursos nuevoCurso = datos();
            cursoModificar.setNombre_curso(nuevoCurso.getNombre_curso());
            cursoModificar.setTemas(nuevoCurso.getTemas());
            cursoModificar.setCompetencias(nuevoCurso.getCompetencias());

            cursosRepository.modificar(cursoModificar);
            JOptionPane.showMessageDialog(null, "Curso modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El curso con ID " + idCursoModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idCursoBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del curso a buscar:"));
        Cursos cursoBuscar = cursosRepository.porCodigo(idCursoBuscar);

        if (cursoBuscar != null) {
            JOptionPane.showMessageDialog(null, "Curso encontrado:\n" + cursoBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El curso con ID " + idCursoBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idCursoEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del curso a eliminar:"));
        Cursos cursoEliminar = cursosRepository.porCodigo(idCursoEliminar);

        if (cursoEliminar != null) {
            cursosRepository.eliminar(idCursoEliminar);
            JOptionPane.showMessageDialog(null, "Curso eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El curso con ID " + idCursoEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Cursos> cursos = cursosRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Cursos:\n");
        for (Cursos curso : cursos) {
            stringBuilder.append(curso.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU CURSOS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}
