package Services;

import Models.Ciudad;
import Repository.CiudadImpl;
import javax.swing.JOptionPane;
import java.util.List;

public class CiudadServices implements Services {
    private static final CiudadImpl ciudadRepository = new CiudadImpl();
    
    @Override
    public Ciudad datos() {
        Ciudad c = new Ciudad();
        String nombre_ciudad = JOptionPane.showInputDialog("Digite el nombre de la ciudad: ");
        c.setNombre_cuidad(nombre_ciudad);
        return c; // Implementa seg�n sea necesario
    }

    @Override
    public void guardar() {
        String nombre_ciudad = JOptionPane.showInputDialog("Digite el nombre de la ciudad: ");
        Ciudad c = new Ciudad();
        c.setNombre_cuidad(nombre_ciudad);
        ciudadRepository.guardar(c);
        JOptionPane.showMessageDialog(null, "DATOS GUARDADOS");
    }

    @Override
    public void modificar() {
        int id_ciudad = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la ciudad que se va modificar: "));
        Ciudad c = new Ciudad();
        c.setId_cuidad(id_ciudad);
        
        String nombre_ciudad = JOptionPane.showInputDialog("Digite el nombre de la ciudad: ");
        c.setNombre_cuidad(nombre_ciudad);
        
        ciudadRepository.modificar(c);
        JOptionPane.showMessageDialog(null,"DATOS MODIFICADOS \n"
               + "Codigo ciudad: "+c.getId_cuidad()+ "\n Nombre:"+c.getNombre_cuidad());
    }

    @Override
    public void buscar() {
        int id_ciudad = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la ciudad que se va a buscar: "));
        Ciudad c = ciudadRepository.porCodigo(id_ciudad);
        
        if (c != null) {
            JOptionPane.showMessageDialog(null, "ID ENCONTRADO: \n"
            + "Codigo ciudad: "+c.getId_cuidad()+ "\n Nombre:"+c.getNombre_cuidad());
        } else {
            JOptionPane.showMessageDialog(null, "Ciudad no encontrada");
        }
    }

    @Override
    public void eliminar() {
        int id_ciudad = Integer.parseInt(JOptionPane.showInputDialog("Digite el id de la ciudad que se va eliminar: "));
        Ciudad c = new Ciudad();
        c.setId_cuidad(id_ciudad);

        ciudadRepository.eliminar(id_ciudad);
        JOptionPane.showMessageDialog(null, "DATOS ELIMINADOS \n"
        + "Codigo ciudad: "+c.getId_cuidad()+ "\n Nombre:"+c.getNombre_cuidad());
    }

    @Override
    public void listar() {
        // Obtener la lista de ciudades del repositorio
        List<Ciudad> ciudades = ciudadRepository.listar();

        // Verificar si hay ciudades en la lista
        if (ciudades.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay ciudades registradas.");
        } else {
            // Construir un mensaje con la lista de ciudades
            StringBuilder mensaje = new StringBuilder("CIUDADES:\n");
            for (Ciudad c : ciudades) {
                mensaje.append("ID: ").append(c.getId_cuidad()).append(", Nombre: ").append(c.getNombre_cuidad()).append("\n");
            }
            // Mostrar el mensaje con la lista de ciudades
            JOptionPane.showMessageDialog(null, mensaje.toString());
        }
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU CIUDAD*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}

