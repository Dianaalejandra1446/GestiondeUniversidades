package Services;

import Models.Programa;
import Repository.ProgramaImpl;
import Repository.Repository;
import Services.Services;
import java.util.List;
import javax.swing.JOptionPane;

public class ProgramaServices implements Services<Object> {
    
    private static final Repository<Programa> programaRepository = new ProgramaImpl();
    
    @Override
    public Object datos() {
        Programa programa = new Programa();
        
        programa.setNombre_programa(JOptionPane.showInputDialog("Ingrese el nombre del programa:"));
        programa.setNivel_programa(JOptionPane.showInputDialog("Ingrese el nivel del programa:"));
        programa.setCreditos_programa(Integer.parseInt(JOptionPane.showInputDialog("Ingrese los cr�ditos del programa:")));
        
        return programa;
    }

    @Override
    public void guardar() {
        Programa programa = (Programa) datos();
        programaRepository.guardar(programa);
        JOptionPane.showMessageDialog(null, "Programa guardado exitosamente.");
    }

    @Override
    public void modificar() {
        int idProgramaModificar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del programa a modificar:"));
        Programa programaModificar = programaRepository.porCodigo(idProgramaModificar);
        
        if (programaModificar != null) {
            Programa nuevoPrograma = (Programa) datos();
            nuevoPrograma.setId_programa(idProgramaModificar); // Mantener el mismo ID
            programaRepository.modificar(nuevoPrograma);
            JOptionPane.showMessageDialog(null, "Programa modificado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El programa con ID " + idProgramaModificar + " no existe.");
        }
    }

    @Override
    public void buscar() {
        int idProgramaBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del programa a buscar:"));
        Programa programaBuscar = programaRepository.porCodigo(idProgramaBuscar);
        
        if (programaBuscar != null) {
            JOptionPane.showMessageDialog(null, "Programa encontrado:\n" + programaBuscar.toString());
        } else {
            JOptionPane.showMessageDialog(null, "El programa con ID " + idProgramaBuscar + " no existe.");
        }
    }

    @Override
    public void eliminar() {
        int idProgramaEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del programa a eliminar:"));
        Programa programaEliminar = programaRepository.porCodigo(idProgramaEliminar);
        
        if (programaEliminar != null) {
            programaRepository.eliminar(idProgramaEliminar);
            JOptionPane.showMessageDialog(null, "Programa eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "El programa con ID " + idProgramaEliminar + " no existe.");
        }
    }

    @Override
    public void listar() {
        List<Programa> programas = programaRepository.listar();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lista de Programas:\n");
        for (Programa programa : programas) {
            stringBuilder.append(programa.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, stringBuilder.toString());
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU PROGRAMAS*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }
}

