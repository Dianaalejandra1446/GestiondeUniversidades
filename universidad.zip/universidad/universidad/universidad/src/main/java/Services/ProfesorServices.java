package Services;

import Models.Departamento;
import Models.Persona;
import Models.Profesor;
import Repository.DepartamentosImpl;
import Repository.PersonaImpl;
import Repository.ProfesorImpl;
import Repository.Repository;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProfesorServices implements Services<Object> {
    private static final Repository<Profesor> profesorRepository = new ProfesorImpl();
    private static final Repository<Persona> personaRepository = new PersonaImpl();
    private static final Repository<Departamento> departamentosRepository = new DepartamentosImpl();

    @Override
    public Object datos() {
        Profesor pr = new Profesor();

        Persona persona = seleccionarPersona();
        pr.setPersona(persona);

        Departamento departamento = seleccionarDepartamento();
        pr.setDepartamentos(departamento);

        return pr;
    }

    @Override
    public void guardar() {
        Profesor pr = (Profesor) datos();
        profesorRepository.guardar(pr);
        JOptionPane.showMessageDialog(null, "DATOS GUARDADOS:\n" + pr);
    }

    @Override
    public void modificar() {
        int id_profesor = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del profesor que se va modificar: "));
        Profesor pr = profesorRepository.porCodigo(id_profesor);

        if (pr != null) {
            Profesor nuevaInformacion = (Profesor) datos();
            nuevaInformacion.setId_profesor(id_profesor);
            profesorRepository.modificar(nuevaInformacion);
            JOptionPane.showMessageDialog(null, "DATOS MODIFICADOS:\n" + nuevaInformacion);
        } else {
            JOptionPane.showMessageDialog(null, "Profesor no encontrado");
        }
    }

    @Override
    public void buscar() {
        int id_profesor = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del profesor que se va buscar: "));
        Profesor pr = profesorRepository.porCodigo(id_profesor);

        if (pr != null && pr.getId_profesor() == id_profesor) {
            JOptionPane.showMessageDialog(null, "PROFESOR ENCONTRADO:\n" + pr);
        } else {
            JOptionPane.showMessageDialog(null, "Profesor no encontrado");
        }
    }

    @Override
    public void eliminar() {
        int id_profesor = Integer.parseInt(JOptionPane.showInputDialog("Digite el id del profesor que se va a eliminar: "));
        Profesor pr = profesorRepository.porCodigo(id_profesor);

        if (pr != null) {
            profesorRepository.eliminar(id_profesor);
            JOptionPane.showMessageDialog(null, "PROFESOR ELIMINADO:\n" + pr);
        } else {
            JOptionPane.showMessageDialog(null, "Profesor no encontrado");
        }
    }

    @Override
    public void listar() {
        List<Profesor> profesores = profesorRepository.listar();

        if (profesores.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay profesores registrados.");
        } else {
            StringBuilder mensaje = new StringBuilder("PROFESORES: \n");
            for (Profesor profesor : profesores) {
                mensaje.append(profesor).append(" \n");
            }
            JOptionPane.showMessageDialog(null, mensaje.toString());
        }
    }

    @Override
    public void menu() {
        int decision;
        do {
            decision = Integer.parseInt(JOptionPane.showInputDialog("***MENU PROFESOR*** \n " +
                    "\n 1. Guardar" +
                    "\n 2. Modificar" +
                    "\n 3. Eliminar" +
                    "\n 4. Buscar" +
                    "\n 5. Listar" +
                    "\n 6. Salir" +
                    "\n\n Seleccione una opci�n:"));

            switch (decision) {
                case 1:
                    guardar();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    buscar();
                    break;
                case 5:
                    listar();
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "Saliendo del men�.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opci�n inv�lida");
                    break;
            }
        } while (decision != 6);
    }

    private Persona seleccionarPersona() {
        List<Persona> personas = personaRepository.listar();
        ArrayList<String> opciones = new ArrayList<>();

        for (Persona p : personas) {
            opciones.add("ID: " + p.getId_persona() +
                    " - Nombre: " + p.getNombre_persona() +
                    " - Tipo Documento: " + p.getTipo_documento_persona() +
                    " - N�mero Documento: " + p.getNumero_documento_persona() +
                    " - Apellido: " + p.getApellido_persona() +
                    " - Direcci�n: " + p.getDireccion_persona() +
                    " - Tel�fono: " + p.getNumero_telefono_persona() +
                    " - Fecha Nacimiento: " + p.getFecha_nacimiento_persona() +
                    " - Sexo: " + p.getSexo_persona() +
                    " - Ciudad ID: " + p.getCiudad_persona().getId_cuidad());
        }

        String[] opcionesArray = opciones.toArray(new String[0]);

        String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
                "Seleccione una persona: ",
                "Elige el id tu persona",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesArray,
                opcionesArray[0]);

        for (Persona p : personas) {
            if (("ID: " + p.getId_persona() + " - Nombre: " + p.getNombre_persona()).equals(opcionSeleccionada)) {
                return p;
            }
        }

        return null;
    }

private Departamento seleccionarDepartamento() {
    List<Departamento> departamentos = departamentosRepository.listar();
    ArrayList<String> opciones = new ArrayList<>();

    // Generar opciones para mostrar en el di�logo
    for (Departamento departamento : departamentos) {
        opciones.add("ID: " + departamento.getId_departamento() + 
                     " - Nombre: " + departamento.getNombre_departamento());
    }

    // Convertir ArrayList a un array de String
    String[] opcionesArray = opciones.toArray(new String[0]);

    // Mostrar el di�logo para que el usuario seleccione un departamento
    String opcionSeleccionada = (String) JOptionPane.showInputDialog(null,
            "Seleccione un departamento: ",
            "Elige el id de tu departamento",
            JOptionPane.QUESTION_MESSAGE,
            null,
            opcionesArray,
            opcionesArray[0]);

    // Buscar el departamento seleccionado en la lista de departamentos y devolverlo
    for (Departamento departamento : departamentos) {
        if (("ID: " + departamento.getId_departamento() + " - Nombre: " + departamento.getNombre_departamento()).equals(opcionSeleccionada)) {
            return departamento;
        }
    }

    return null; // Devolver null si no se seleccion� ning�n departamento
}
}

