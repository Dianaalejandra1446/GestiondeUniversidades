package Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cursos {
    private int id_curso;
    private String nombre_curso;
    private String temas;
    private String competencias;
}
