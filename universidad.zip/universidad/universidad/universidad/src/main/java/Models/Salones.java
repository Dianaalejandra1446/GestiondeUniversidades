package Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Salones {
    private int id_salon;
    private double capacidad;
    private int total_cupos;
    private double numero_identificacion;
    private Edificio edificio;
    private Piso piso;

}
