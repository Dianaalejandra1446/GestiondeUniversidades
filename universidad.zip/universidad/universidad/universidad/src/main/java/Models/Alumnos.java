package Models;

import lombok.*;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class  Alumnos {
    private int id_alumno;
    private double num_carnet;
    private Persona persona;

}
