package Models;

import java.util.List;

import lombok.Data;

@Data
//Terminar de agregar las otras clases 
public class Asignatura {
    private int id_asignatura;
    private String nombre_combinado;
    private int cantidad_creditos;
    private int cupos;
    private Periodo periodo;
    private Profesor profesor;
    private Programa programa;
    private Cursos cursos;

}
