package Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
/*Hacer la tabla Salones */
public class Horario {
    private int id_horario;
    private String dia;
    private String hora_inicio;
    private String hora_fin;
    private Salones salon;
    private Asignatura asignatura;
}
