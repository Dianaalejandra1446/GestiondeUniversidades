package Models;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Persona {
    private int id_persona ;
    private String tipo_documento_persona ;
    private int numero_documento_persona ;
    private String nombre_persona;
    private String apellido_persona;
    private String numero_telefono_persona;
    private String direccion_persona;
    private LocalDate fecha_nacimiento_persona;
    private String sexo_persona;
    private Ciudad ciudad_persona;

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}