package Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Periodo {
    private int id_periodo;
    private String nombre_periodo;
    private int codigo;
    private int anio;
    private String semestre_correspondiente;
    private int credito_periodo;

}
