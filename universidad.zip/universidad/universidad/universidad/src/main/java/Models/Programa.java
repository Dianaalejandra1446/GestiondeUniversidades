package Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Programa {
    private int id_programa;
    private String nombre_programa;
    private String nivel_programa;
    private int creditos_programa;
}
