package Models;


import java.util.ArrayList;
import java.util.List;
import lombok.*;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Profesor {
    private int id_profesor;
    private Persona persona;
    private Departamento departamentos;
     
    
}
