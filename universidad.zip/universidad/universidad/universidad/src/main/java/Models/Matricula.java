package Models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Matricula {
    private int id_matricula;
    private Alumnos alumno;
    private Asignatura asignatura;

    public Matricula(int id_matricula, Alumnos alumno, Asignatura asignatura) {
        this.id_matricula = id_matricula;
        this.alumno = alumno;
        this.asignatura = asignatura;
    }
}
