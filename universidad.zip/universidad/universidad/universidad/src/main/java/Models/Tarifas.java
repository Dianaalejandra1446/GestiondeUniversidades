package Models;

import lombok.AllArgsConstructor;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Tarifas {
    private int id_tarifa;
    private double valor_credito;
    private Periodo periodo;
    private Programa programa;

    public double calcTotal(double total_pagar){
        /*Logica de total */
        /*total_pagar =*/
        return total_pagar;
    }
}
