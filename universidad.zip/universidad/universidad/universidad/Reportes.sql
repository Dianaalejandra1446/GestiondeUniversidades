/*Reportes*/
/*lISTA DE ESTUDIANTES MATRICULADOS*/
SELECT p.nombre, p.apellido, a.num_carnet
FROM Alumnos a
INNER JOIN Persona p ON a.id_persona = p.id_persona
INNER JOIN Matriculas m ON a.id_alumno = m.id_alumno;
/*Forma descendente num matriculados*/
SELECT pr.nombre_programa AS 'Programa', COUNT(*) AS 'Número de Matriculados'
FROM Matriculas m
JOIN Asignatura asi ON m.id_asignatura = asi.id_asignatura
JOIN Programas pr ON asi.id_programa = pr.id_programa
GROUP BY pr.nombre_programa
ORDER BY COUNT(*) DESC;
/*Horario*/
SELECT h.dia, h.hora_inicio, h.hora_fin, s.num_identificacion AS 'Salón', c.nombre_curso AS 'Curso'
FROM Alumnos a
JOIN Matriculas m ON a.id_alumno = m.id_alumno
JOIN Asignatura asi ON m.id_asignatura = asi.id_asignatura
JOIN Horario h ON asi.id_asignatura = h.id_asignatura
JOIN Salones s ON h.id_salon = s.id_salon
JOIN Cursos c ON asi.id_curso = c.id_curso
WHERE a.num_carnet = 808;
/*Costo del semestre segun asignatura*/
SELECT a.num_carnet AS 'Número de Carnet',
       SUM(t.valor_credito * asignatura.cantidad_creditos) AS 'Costo del Semestre'
FROM Alumnos a
JOIN Matriculas m ON a.id_alumno = m.id_alumno
JOIN Asignatura ON m.id_asignatura = Asignatura.id_asignatura
JOIN Tarifas t ON Asignatura.id_programa = t.id_programa AND m.id_periodo = t.id_periodo
GROUP BY a.num_carnet;


/*Ingresos de la universidad por semestre*/

SELECT SUM(subquery.Costo del Semestre) AS 'Ingresos del Semestre'
FROM (
    SELECT a.num_carnet AS 'Número de Carnet',
           SUM(t.valor_credito * asignatura.cantidad_creditos) AS 'Costo del Semestre'
    FROM Alumnos a
    JOIN Matriculas m ON a.id_alumno = m.id_alumno
    JOIN Asignatura ON m.id_asignatura = Asignatura.id_asignatura
    JOIN Tarifas t ON Asignatura.id_programa = t.id_programa AND m.id_periodo = t.id_periodo
    GROUP BY a.num_carnet
) AS subquery;

